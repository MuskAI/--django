from django.shortcuts import render
from django.http import HttpResponse
from django.shortcuts import render
from .models import Signin as Signint
from .models import AdminSignin
from .models import Sinfo as sinfo
from .models import Chooselesson
from .models import Club as club
from .models import Allqua as allqua
from .models import Allability as allability
# Create your views here.


def index(request):
    return render(request,'../templates/index.html')

def login(request):
    return render(request, '../templates/login.html')

def stu_inf(request):
    return render(request, '../templates/stu_inf.html')

def jishi_score(request):
    return render(request, '../templates/jishi_score.html')

def Signin(request):
    return render(request,'signin.html')

def presslogin(request):
    usernum = request.POST['usernum']
    password = request.POST['password']
    usernum = str(usernum)
    password = str(password)
    print(usernum)
    print(password)
    # 验证登录信息
    if Signint.objects.filter(sno=usernum, password=password):
        return render(request, 'index.html')
    else:
        return HttpResponse('没有该用户信息')

def zongce(request):
    return render(request,'zongce_score.html')

def presssignin(request):
    # 注册一个用户
    usernum = request.POST['usernum']
    password_first = request.POST['password_first']
    password_second = request.POST['password_second']
    if str(password_first) == str(password_second):
        print('两次密码一致，开始判断是否已经注册')
        if Signint.objects.filter(sno=usernum,password=password_second):
            return HttpResponse('该用户已经注册，请直接登录')

        else:
            Signint.objects.create(sno=usernum,password=password_second)
            return render(request, 'login.html')
    else:
        return HttpResponse('输入密码不一致，请返回重新输入')

def search(request):
    return render(request,'search.html')


def admin_index(request):
    return render(request,'admin_index.html')

def presssearch(request):
    return render(request,'admin_index.html')


def result(request):
    usernum =None

    return render(request,'result.html',{'usernum':usernum})


def login_admin(request):
    return render(request,'login_admin.html')

def presslogin_admin(request):
    usernum = request.POST['usernum']
    password = request.POST['password']
    usernum = str(usernum)
    password = str(password)
    # 验证登录信息
    if Signint.objects.filter(sno=usernum, password=password):
        return render(request, 'admin_index.html')
    else:
        return HttpResponse('没有该用户信息,请联系班长')

def pressstu_inf(request):
    SNo = request.POST.get('SNo')
    SNation = request.POST.get('SNation')

    # SNation = '汉族'
    SName = request.POST.get('SName')
    SSex = request.POST.get('SSex')
    SDate = request.POST.get('SDate')
    SID = request.POST.get('SID')
    SHigh = request.POST['SHigh']
    SNP = request.POST.get('SNP')
    SHP = request.POST.get('SHP')
    SPhone = request.POST.get('SPhone')
    SFP = request.POST.get('SFP')
    SMP = request.POST.get('SMP')
    SQQ = request.POST.get('SQQ')
    SPO = request.POST.get('SPO')
    SRB = request.POST.get('SPR')
    SDN = request.POST.get('SDN')
    SICBC = request.POST.get('SICBC')
    SNote = request.POST.get('SNote')
    sinfo.objects.create(sno = SNo,snation = SNation,sname = SName, ssex = SSex, sdata = SDate, sid = SID, shigh = SHigh
                         , snp = SNP, shp = SHP, sphone = SPhone, sfp = SFP, smp = SMP, sqq = SQQ, spo = SPO, srb = SRB,
                         sdn = SDN, sicbc = SICBC,note=SNote)
    return HttpResponse('创建成功')

def pressseach1(request):
    # 查询指定人的所有信息 返回到页面上面
    inputword = request.POST.get('SearchWord1')

    inputword = str(inputword)
    if inputword[0] == '1':
        ret = sinfo.objects.filter(sno=inputword).values()
    else:
        ret = sinfo.objects.filter(sname=inputword).values()


    xuehao = list(ret[0].values())[0]
    Nation = list(ret[0].values())[1]
    Name = list(ret[0].values())[2]
    Sex = list(ret[0].values())[3]
    BirthDate = list(ret[0].values())[4]
    IdCard = list(ret[0].values())[5]
    HighSchool = list(ret[0].values())[6]
    jiguan = list(ret[0].values())[7]
    HomePlace = list(ret[0].values())[8]
    MyPhone = list(ret[0].values())[9]
    FatherPhone = list(ret[0].values())[10]
    MotherPhone = list(ret[0].values())[11]
    QQ = list(ret[0].values())[12]
    zhengji = list(ret[0].values())[13]
    zongjiao = list(ret[0].values())[14]
    Dormitary = list(ret[0].values())[15]
    BankCard = list(ret[0].values())[16]
    Note = list(ret[0].values())[17]
    return render(request, 'sinfotable.html',
                  context={'xuehao': xuehao, 'Nation': Nation, 'Name': Name, 'Sex': Sex, 'BirthDate': BirthDate,
                           'IdCard': IdCard, 'HightSchool': HighSchool, 'jiguan': jiguan, 'HomePlace': HomePlace,
                           'MyPhone': MyPhone
                      , "FatherPhone": FatherPhone, 'MotherPhone': MotherPhone, 'QQ': QQ, 'zhengji': zhengji,
                           'zongjiao': zongjiao, 'Dormitary': Dormitary,
                           "BankCard": BankCard, "Note": Note
                           })


def pressseach2(request):
    # 查询课程信息
    inputword = request.POST.get('SearchWord2')

    inputword = str(inputword)

    ret = Chooselesson.objects.filter(sno = inputword).values()


    # xuehao = list(ret[0].values())[0]
    # ClassName = list(ret[0].values())[1]
    # ClassScore = list(ret[0].values())[2]
    # ClassFlag = list(ret[0].values())[3]
    # ClassType = list(ret[0].values())[4]
    #
    # return render(request,'classtable.html',
    #               context={'xuehao': xuehao, 'ClassName': ClassName, 'ClassScore': ClassScore, 'ClassFlag': ClassFlag, 'ClassType': ClassType,
    #                      })
    ret = list(ret.values())
    return render(request, 'classtable.html', context={'classinfo': ret})
def pressseach3(request):
    inputword = request.POST.get('SearchWord3')

    inputword = str(inputword)
    if inputword[0] == '1':
        ret = club.objects.filter(sno=inputword).values()

    xuehao = list(ret[0].values())[0]
    ClubName = list(ret[0].values())[1]
    zhiwei = list(ret[0].values())[2]

    return render(request,'clubtable.html',
                  context={'xuehao': xuehao, 'ClubName': ClubName, 'zhiwei': zhiwei})


def pressseach4(request):
    inputword = request.POST.get('SearchWord4')
    inputword = str(inputword)
    if inputword[0] == '1':
        ret = allqua.objects.filter(sno=inputword).values()

    xuehao = list(ret[0].values())[0]
    jtfs = list(ret[0].values())[1]
    grfs = list(ret[0].values())[2]
    kf = list(ret[0].values())[3]

    return render(request,'AllQuatable.html',
                  context={'xuehao': xuehao, 'jtfs': jtfs, 'grfs': grfs, 'kf':kf})
    ret = list(ret.values())
    return render(request,'AllQuatable.html',context={'allquainfo':ret})

def pressseach5(request):
    inputword = request.POST.get('SearchWord5')
    inputword = str(inputword)
    if inputword[0] == '1':
        ret = allability.objects.filter(sno=inputword).values()

    xuehao = list(ret[0].values())[0]
    yjcx = list(ret[0].values())[1]
    zyjn = list(ret[0].values())[2]
    gbkh = list(ret[0].values())[3]
    shsj = list(ret[0].values())[4]
    wttc = list(ret[0].values())[5]
    return render(request,'AllAbilitytable.html',
                  context={'xuehao': xuehao, 'yjcx': yjcx, 'zyjn': zyjn, 'gbkh':gbkh,'shsj':shsj,"wttc":wttc})


def pressseach6(request):
    # 查询数据库中的所有信息 返回到页面上面
    inputword = request.POST.get('SearchWord6')
    response1 = None
    ret = sinfo.objects.all()
    ret = list(ret.values())
    return render(request,'allsinfotable.html',context={'info':ret})

def pressseach7(request):
    # 删除某条基本信息记录
    inputword = request.POST.get('SearchWord7')
    if inputword[0] == '1':
        ret = sinfo.objects.filter(sno=inputword).values()
        if ret:
            ret = sinfo.objects.get(sno=inputword)
            ret.delete()
            return HttpResponse('删除信息成功')
        else:
            return HttpResponse('要删除的信息不存在')
    else:
        ret = sinfo.objects.filter(sname=inputword).values()
        if ret:
            ret = sinfo.objects.get(sname=inputword)
            ret.delete()
            return HttpResponse('删除信息成功')
        else:
            return HttpResponse('要删除的信息不存在')

def pressseach8(request):
    # 修改信息
    # inputword = request.POST.get('SearchWord8')
    return render(request,'alterpage.html')



def professionscore(request):
    ckb1 = request.POST.get('checkbox1')
    ckb2 = request.POST.get('checkbox2')
    ckb3 = request.POST.get('checkbox3')
    ckb4 = request.POST.get('checkbox4')
    ckb5 = request.POST.get('checkbox5')
    ckb6 = request.POST.get('checkbox6')
    print('flag')
    print(ckb1)
    return HttpResponse('计算成功！')

def sinfotable(request):
    return render(request,'sinfotable.html')


def clubtable(request):
    return


def selecttables(request):
    flag = request.POST.get('tables')
    print(flag)
    flag = int(flag)
    if flag==1:
        str1 = "请选择要修改的学生基本信息"
        return render(request, 'alterpage.html',context={'str1':str1, 'start1':True})
    elif flag ==2:
        str1 = "请选择要修改的学生成绩"
        return render(request, 'alterpage.html', context={'str1': str1, 'start2': True})
    elif flag ==3:
        str1 = "请选择要修改的品德纪实分数"
        return render(request, 'alterpage.html', context={'str1': str1, 'start3': True})
    elif flag ==4:
        str1 = "请选择要修改的综合能力分数"
        return render(request, 'alterpage.html', context={'str1': str1, 'start4': True})

def table1_modify(request):
    rightdata = request.POST.get('table1_input')
    flag = request.POST.get('table1')
    sno = request.POST.get('xuehao')
    print('asd')
    print(rightdata)
    print(sno)
    flag = int(flag)
    if flag ==1:
        #修改家庭住址
        temp = sinfo.objects.get(sno =sno)
        temp.SHP = rightdata
        temp.save()
        return HttpResponse('modify data ok!!')
    elif flag ==2:
        #修改本人电话号码
        temp = sinfo.objects.get(sno=sno)
        temp.SPhone = rightdata
        temp.save()
        return HttpResponse('modify data ok!!')

def table2_modify(request):
    rightdata =request.POST.get('table2_input')
    sno = request.POST.get('xuehao')
    flag = request.POST.get('table2')
    flag = int(flag)
    if flag ==1:
        #成绩
        temp = Chooselesson.objects.get(sno=sno)
        temp.Score = rightdata
        temp.save()
        return HttpResponse('modify data ok!!')
    elif flag ==2:
        #课程标记
        temp = Chooselesson.objects.get(sno=sno)
        temp.LSign = rightdata
        temp.save()
        return HttpResponse('modify data ok!!')
    elif flag == 3:
        # 考试性质
        temp = Chooselesson.objects.get(sno=sno)
        temp.LExam = rightdata
        temp.save()
        return HttpResponse('modify data ok!!')

def table3_modify(request):
    rightdata =request.POST.get('table3_input')
    sno = request.POST.get('xuehao')
    flag = request.POST.get('table3')
    flag = int(flag)
    if flag ==1:
        #集体荣誉加分项总分
        temp = allqua.objects.get(sno=sno)
        temp.GScore = rightdata
        temp.save()
        return HttpResponse('modify data ok!!')
    elif flag ==2:
        #个人荣誉加分项总分
        temp = allqua.objects.get(sno=sno)
        temp.PScore = rightdata
        temp.save()
        return HttpResponse('modify data ok!!')
    elif flag == 3:
        # 扣分项总分
        temp = allqua.objects.get(sno=sno)
        temp.DScore = rightdata
        temp.save()
        return HttpResponse('modify data ok!!')

def table4_modify(request):
    rightdata =request.POST.get('table4_input')
    sno = request.POST.get('xuehao')
    flag = request.POST.get('table4')
    flag = int(flag)
    if flag ==1:
        #研究创新总分
        temp = allability.objects.get(sno=sno)
        temp.RScore = rightdata
        temp.save()
        return HttpResponse('modify data ok!!')
    elif flag ==2:
        #专业技能总分
        temp = allability.objects.get(sno=sno)
        temp.PSScore = rightdata
        temp.save()
        return HttpResponse('modify data ok!!')
    elif flag == 3:
        # 干部考核总分
        temp = allqua.objects.get(sno=sno)
        temp.CScore = rightdata
        temp.save()
        return HttpResponse('modify data ok!!')
    elif flag == 4:
        # 社会实践总分
        temp = allqua.objects.get(sno=sno)
        temp.SoScore = rightdata
        temp.save()
        return HttpResponse('modify data ok!!')