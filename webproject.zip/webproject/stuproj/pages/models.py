# This is an auto-generated Django model module.
# You'll have to do the following manually to clean this up:
#   * Rearrange models' order
#   * Make sure each model has one field with primary_key=True
#   * Make sure each ForeignKey and OneToOneField has `on_delete` set to the desired behavior
#   * Remove `managed = False` lines if you wish to allow Django to create, modify, and delete the table
# Feel free to rename the models, but don't rename db_table values or field names.
from django.db import models


class AdminSignin(models.Model):
    sno = models.CharField(db_column='SNo', primary_key=True, max_length=10)  # Field name made lowercase.
    password = models.CharField(db_column='PassWord', max_length=18)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'admin_signin'


class Allability(models.Model):
    sno = models.CharField(db_column='SNo', primary_key=True, max_length=10)  # Field name made lowercase.
    rscore = models.FloatField(db_column='RScore', blank=True, null=True)  # Field name made lowercase.
    psscore = models.FloatField(db_column='PSScore', blank=True, null=True)  # Field name made lowercase.
    cscore = models.FloatField(db_column='CScore', blank=True, null=True)  # Field name made lowercase.
    soscore = models.FloatField(db_column='SoScore', blank=True, null=True)  # Field name made lowercase.
    spscore = models.FloatField(db_column='SPScore', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'allability'


class Allqua(models.Model):
    sno = models.CharField(db_column='SNo', primary_key=True, max_length=10)  # Field name made lowercase.
    g_score = models.FloatField(db_column='G_Score', blank=True, null=True)  # Field name made lowercase.
    p_score = models.FloatField(db_column='P_Score', blank=True, null=True)  # Field name made lowercase.
    d_score = models.FloatField(db_column='D_Score', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'allqua'


class Ascore(models.Model):
    sno = models.CharField(db_column='SNo', primary_key=True, max_length=10)  # Field name made lowercase.
    ascore = models.FloatField(db_column='AScore', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'ascore'


class Cadres(models.Model):
    c_num = models.IntegerField(db_column='C_NUM', primary_key=True)  # Field name made lowercase.
    c_item = models.CharField(db_column='C_Item', max_length=100, blank=True, null=True)  # Field name made lowercase.
    c_score = models.FloatField(db_column='C_Score', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'cadres'


class Cadres1(models.Model):
    sno = models.CharField(db_column='SNo', primary_key=True, max_length=10)  # Field name made lowercase.
    c_num = models.IntegerField(db_column='C_Num')  # Field name made lowercase.
    c_prove = models.CharField(db_column='C_Prove', max_length=100, blank=True, null=True)  # Field name made lowercase.
    c_istrue = models.CharField(db_column='C_isTrue', max_length=6, blank=True, null=True)  # Field name made lowercase.
    c_score = models.FloatField(db_column='C_Score', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'cadres1'
        unique_together = (('sno', 'c_num'),)


class Chooselesson(models.Model):
    sno = models.CharField(db_column='SNo', primary_key=True, max_length=10)  # Field name made lowercase.
    lname = models.CharField(db_column='LName', max_length=20)  # Field name made lowercase.
    score = models.FloatField(db_column='Score', blank=True, null=True)  # Field name made lowercase.
    lsign = models.CharField(db_column='LSign', max_length=2, blank=True, null=True)  # Field name made lowercase.
    lexam = models.CharField(db_column='LExam', max_length=4, blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'chooselesson'
        unique_together = (('sno', 'lname'),)


class Club(models.Model):
    sno = models.CharField(db_column='SNo', primary_key=True, max_length=10)  # Field name made lowercase.
    cname = models.CharField(db_column='CName', max_length=8)  # Field name made lowercase.
    post = models.CharField(db_column='Post', max_length=20, blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'club'
        unique_together = (('sno', 'cname'),)


class Deduct(models.Model):
    d_num = models.IntegerField(db_column='D_NUM', primary_key=True)  # Field name made lowercase.
    d_item = models.CharField(db_column='D_Item', max_length=100, blank=True, null=True)  # Field name made lowercase.
    d_score = models.FloatField(db_column='D_Score', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'deduct'


class Deduct1(models.Model):
    sno = models.CharField(db_column='SNo', primary_key=True, max_length=10)  # Field name made lowercase.
    d_num = models.IntegerField(db_column='D_Num')  # Field name made lowercase.
    d_prove = models.CharField(db_column='D_Prove', max_length=100, blank=True, null=True)  # Field name made lowercase.
    d_istrue = models.CharField(db_column='D_isTrue', max_length=6, blank=True, null=True)  # Field name made lowercase.
    d_score = models.FloatField(db_column='D_Score', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'deduct1'
        unique_together = (('sno', 'd_num'),)


class DjangoMigrations(models.Model):
    app = models.CharField(max_length=255)
    name = models.CharField(max_length=255)
    applied = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'django_migrations'


class Groupadd(models.Model):
    g_num = models.IntegerField(db_column='G_NUM', primary_key=True)  # Field name made lowercase.
    g_item = models.CharField(db_column='G_Item', max_length=100, blank=True, null=True)  # Field name made lowercase.
    g_score = models.FloatField(db_column='G_Score', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'groupadd'


class Groupadd1(models.Model):
    monitor = models.CharField(db_column='Monitor', primary_key=True, max_length=4)  # Field name made lowercase.
    g_num = models.IntegerField(db_column='G_Num')  # Field name made lowercase.
    sno = models.CharField(db_column='SNo', max_length=10)  # Field name made lowercase.
    g_prove = models.CharField(db_column='G_Prove', max_length=100, blank=True, null=True)  # Field name made lowercase.
    g_istrue = models.CharField(db_column='G_isTrue', max_length=6, blank=True, null=True)  # Field name made lowercase.
    g_score = models.FloatField(db_column='G_Score', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'groupadd1'
        unique_together = (('monitor', 'g_num', 'sno'),)


class Lesson(models.Model):
    lname = models.CharField(db_column='LName', primary_key=True, max_length=45)  # Field name made lowercase.
    ltype = models.CharField(db_column='LType', max_length=5, blank=True, null=True)  # Field name made lowercase.
    lcredit = models.FloatField(db_column='LCredit', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'lesson'


class Manager(models.Model):
    sno = models.CharField(db_column='SNo', primary_key=True, max_length=10)  # Field name made lowercase.
    monitor = models.CharField(db_column='Monitor', max_length=4)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'manager'
        unique_together = (('sno', 'monitor'),)


class Personaladd(models.Model):
    p_num = models.IntegerField(db_column='P_NUM', primary_key=True)  # Field name made lowercase.
    p_item = models.CharField(db_column='P_Item', max_length=100, blank=True, null=True)  # Field name made lowercase.
    p_score = models.FloatField(db_column='P_Score', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'personaladd'


class Personaladd1(models.Model):
    sno = models.CharField(db_column='SNo', primary_key=True, max_length=10)  # Field name made lowercase.
    p_num = models.IntegerField(db_column='P_Num')  # Field name made lowercase.
    p_prove = models.CharField(db_column='P_Prove', max_length=100, blank=True, null=True)  # Field name made lowercase.
    p_istrue = models.CharField(db_column='P_isTrue', max_length=6, blank=True, null=True)  # Field name made lowercase.
    p_score = models.FloatField(db_column='P_Score', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'personaladd1'
        unique_together = (('sno', 'p_num'),)


class Proskill(models.Model):
    ps_num = models.IntegerField(db_column='PS_NUM', primary_key=True)  # Field name made lowercase.
    ps_item = models.CharField(db_column='PS_Item', max_length=100, blank=True, null=True)  # Field name made lowercase.
    ps_score = models.FloatField(db_column='PS_Score', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'proskill'


class Proskill1(models.Model):
    sno = models.CharField(db_column='SNo', primary_key=True, max_length=10)  # Field name made lowercase.
    ps_num = models.IntegerField(db_column='PS_Num')  # Field name made lowercase.
    ps_prove = models.CharField(db_column='PS_Prove', max_length=100, blank=True, null=True)  # Field name made lowercase.
    ps_istrue = models.CharField(db_column='PS_isTrue', max_length=6, blank=True, null=True)  # Field name made lowercase.
    ps_score = models.FloatField(db_column='PS_Score', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'proskill1'
        unique_together = (('sno', 'ps_num'),)


class Qscore(models.Model):
    sno = models.CharField(db_column='SNo', primary_key=True, max_length=10)  # Field name made lowercase.
    qscore = models.FloatField(db_column='QScore', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'qscore'


class Research(models.Model):
    r_num = models.IntegerField(db_column='R_NUM', primary_key=True)  # Field name made lowercase.
    r_item = models.CharField(db_column='R_Item', max_length=100, blank=True, null=True)  # Field name made lowercase.
    r_score = models.FloatField(db_column='R_Score', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'research'


class Research1(models.Model):
    sno = models.CharField(db_column='SNo', primary_key=True, max_length=10)  # Field name made lowercase.
    r_num = models.IntegerField(db_column='R_Num')  # Field name made lowercase.
    r_prove = models.CharField(db_column='R_Prove', max_length=100, blank=True, null=True)  # Field name made lowercase.
    r_istrue = models.CharField(db_column='R_isTrue', max_length=6, blank=True, null=True)  # Field name made lowercase.
    r_score = models.FloatField(db_column='R_Score', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'research1'
        unique_together = (('sno', 'r_num'),)


class Signin(models.Model):
    sno = models.CharField(db_column='SNo', primary_key=True, max_length=10)  # Field name made lowercase.
    password = models.CharField(db_column='PassWord', max_length=18, blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'signin'


class Sinfo(models.Model):
    sno = models.CharField(db_column='SNo', primary_key=True, max_length=10)  # Field name made lowercase.
    snation = models.CharField(db_column='SNation', max_length=10, blank=True, null=True)  # Field name made lowercase.
    sname = models.CharField(db_column='SName', max_length=8, blank=True, null=True)  # Field name made lowercase.
    ssex = models.CharField(db_column='SSex', max_length=2, blank=True, null=True)  # Field name made lowercase.
    sdata = models.DateField(db_column='Sdata', blank=True, null=True)  # Field name made lowercase.
    sid = models.CharField(db_column='SID', max_length=18, blank=True, null=True)  # Field name made lowercase.
    shigh = models.CharField(db_column='SHigh', max_length=45, blank=True, null=True)  # Field name made lowercase.
    snp = models.CharField(db_column='SNP', max_length=12, blank=True, null=True)  # Field name made lowercase.
    shp = models.CharField(db_column='SHP', max_length=100, blank=True, null=True)  # Field name made lowercase.
    sphone = models.CharField(db_column='SPhone', max_length=12, blank=True, null=True)  # Field name made lowercase.
    sfp = models.CharField(db_column='SFP', max_length=12, blank=True, null=True)  # Field name made lowercase.
    smp = models.CharField(db_column='SMP', max_length=12, blank=True, null=True)  # Field name made lowercase.
    sqq = models.CharField(db_column='SQQ', max_length=12, blank=True, null=True)  # Field name made lowercase.
    spo = models.CharField(db_column='SPO', max_length=4, blank=True, null=True)  # Field name made lowercase.
    srb = models.CharField(db_column='SRB', max_length=4, blank=True, null=True)  # Field name made lowercase.
    sdn = models.CharField(db_column='SDN', max_length=10, blank=True, null=True)  # Field name made lowercase.
    sicbc = models.CharField(db_column='SICBC', max_length=19, blank=True, null=True)  # Field name made lowercase.
    note = models.CharField(max_length=100, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'sinfo'


class Social(models.Model):
    so_num = models.IntegerField(db_column='So_NUM', primary_key=True)  # Field name made lowercase.
    so_item = models.CharField(db_column='So_Item', max_length=100, blank=True, null=True)  # Field name made lowercase.
    so_score = models.FloatField(db_column='So_Score', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'social'


class Social1(models.Model):
    sno = models.CharField(db_column='SNo', primary_key=True, max_length=10)  # Field name made lowercase.
    so_num = models.IntegerField(db_column='So_Num')  # Field name made lowercase.
    so_prove = models.CharField(db_column='So_Prove', max_length=100, blank=True, null=True)  # Field name made lowercase.
    so_istrue = models.CharField(db_column='So_isTrue', max_length=6, blank=True, null=True)  # Field name made lowercase.
    so_score = models.FloatField(db_column='So_Score', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'social1'
        unique_together = (('sno', 'so_num'),)


class Sports(models.Model):
    sp_num = models.IntegerField(db_column='Sp_NUM', primary_key=True)  # Field name made lowercase.
    sp_item = models.CharField(db_column='Sp_Item', max_length=100, blank=True, null=True)  # Field name made lowercase.
    sp_score = models.FloatField(db_column='Sp_Score', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'sports'


class Sports1(models.Model):
    sno = models.CharField(db_column='SNo', primary_key=True, max_length=10)  # Field name made lowercase.
    sp_num = models.IntegerField(db_column='Sp_Num')  # Field name made lowercase.
    sp_prove = models.CharField(db_column='Sp_Prove', max_length=100, blank=True, null=True)  # Field name made lowercase.
    sp_istrue = models.CharField(db_column='Sp_isTrue', max_length=6, blank=True, null=True)  # Field name made lowercase.
    sp_score = models.FloatField(db_column='Sp_Score', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'sports1'
        unique_together = (('sno', 'sp_num'),)
