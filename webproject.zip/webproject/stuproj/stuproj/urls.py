"""stuproj URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from django.conf.urls import url
from pages import views as page_views
urlpatterns = [
    path('admin/', admin.site.urls),
    url(r'^index',page_views.index),

    url(r'^login$',page_views.login),
    url(r'^stu_inf',page_views.stu_inf),
    url(r'^jishi_score',page_views.jishi_score),
    url(r'^$',page_views.login),
    url(r'^presslogin$',page_views.presslogin),
    url(r'^zongce',page_views.zongce),
    url(r'^signin',page_views.Signin),
    url(r'^search',page_views.search),
    url(r'^admin_index$',page_views.admin_index),
    url(r'^presssignin$',page_views.presssignin),
    url(r'^login_admin',page_views.login_admin),
    url(r'^presslogin_admin$',page_views.presslogin_admin),
    url(r'^pressstu_inf', page_views.pressstu_inf),
    url(r'^presssearch1', page_views.pressseach1),
    url(r'^presssearch2', page_views.pressseach2),
    url(r'^presssearch3', page_views.pressseach3),
    url(r'^professionscore',page_views.professionscore),
    url(r'^sinfotable',page_views.sinfotable),
    url(r'^clubtable',page_views.clubtable),
    url(r'^presssearch4', page_views.pressseach4),
    url(r'^presssearch5', page_views.pressseach5),
    url(r'^presssearch6', page_views.pressseach6),
    url(r'^presssearch7', page_views.pressseach7),
    url(r'^presssearch8', page_views.pressseach8),
    url(r'^selecttables',page_views.selecttables),
    url(r'^table1_modify', page_views.table1_modify),
    url(r'^table1_modify', page_views.table2_modify),
    url(r'^table1_modify', page_views.table3_modify),
    url(r'^table1_modify', page_views.table4_modify),
]
