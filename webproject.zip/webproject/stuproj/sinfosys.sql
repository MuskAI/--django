/*
 Navicat Premium Data Transfer

 Source Server         : chensql
 Source Server Type    : MySQL
 Source Server Version : 80020
 Source Host           : localhost:3306
 Source Schema         : sinfosys

 Target Server Type    : MySQL
 Target Server Version : 80020
 File Encoding         : 65001

 Date: 09/07/2020 16:04:20
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for admin_signin
-- ----------------------------
DROP TABLE IF EXISTS `admin_signin`;
CREATE TABLE `admin_signin`  (
  `SNo` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `PassWord` varchar(18) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`SNo`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of admin_signin
-- ----------------------------
INSERT INTO `admin_signin` VALUES ('1812190208', 'chenh');

-- ----------------------------
-- Table structure for allability
-- ----------------------------
DROP TABLE IF EXISTS `allability`;
CREATE TABLE `allability`  (
  `SNo` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `RScore` float(3, 1) NULL DEFAULT NULL,
  `PSScore` float(3, 1) NULL DEFAULT NULL,
  `CScore` float(3, 1) NULL DEFAULT NULL,
  `SoScore` float(3, 1) NULL DEFAULT NULL,
  `SPScore` float(3, 1) NULL DEFAULT NULL,
  PRIMARY KEY (`SNo`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of allability
-- ----------------------------
INSERT INTO `allability` VALUES ('1402080224', 1.0, 2.0, 3.0, 4.0, 5.0);
INSERT INTO `allability` VALUES ('1710080232', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `allability` VALUES ('1801110602', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `allability` VALUES ('1805090112', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `allability` VALUES ('1805090221', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `allability` VALUES ('1805100214', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `allability` VALUES ('1805100341', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `allability` VALUES ('1806070417', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `allability` VALUES ('1807090414', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `allability` VALUES ('1810080435', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `allability` VALUES ('1811060137', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `allability` VALUES ('1812190202', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `allability` VALUES ('1812190208', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `allability` VALUES ('1812190210', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `allability` VALUES ('1812190218', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `allability` VALUES ('1812190219', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `allability` VALUES ('1812190220', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `allability` VALUES ('1812190224', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `allability` VALUES ('1812190226', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `allability` VALUES ('1812190227', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `allability` VALUES ('1812190228', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `allability` VALUES ('1812190229', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `allability` VALUES ('1812190230', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `allability` VALUES ('1812190231', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `allability` VALUES ('1812190232', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `allability` VALUES ('1812190503', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `allability` VALUES ('1812190505', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `allability` VALUES ('1812190509', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `allability` VALUES ('1812190521', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `allability` VALUES ('1812190522', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `allability` VALUES ('1812190532', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `allability` VALUES ('1819130205', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `allability` VALUES ('1820100608', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `allability` VALUES ('1820100703', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `allability` VALUES ('1822010211', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `allability` VALUES ('1823040320', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `allability` VALUES ('1835010206', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `allability` VALUES ('1835020601', NULL, NULL, NULL, NULL, NULL);

-- ----------------------------
-- Table structure for allqua
-- ----------------------------
DROP TABLE IF EXISTS `allqua`;
CREATE TABLE `allqua`  (
  `SNo` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `G_Score` float(3, 1) NULL DEFAULT NULL,
  `P_Score` float(3, 1) NULL DEFAULT NULL,
  `D_Score` float(3, 1) NULL DEFAULT NULL,
  PRIMARY KEY (`SNo`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of allqua
-- ----------------------------
INSERT INTO `allqua` VALUES ('1402080224', NULL, NULL, NULL);
INSERT INTO `allqua` VALUES ('1710080232', NULL, NULL, NULL);
INSERT INTO `allqua` VALUES ('1801110602', NULL, NULL, NULL);
INSERT INTO `allqua` VALUES ('1805090112', NULL, NULL, NULL);
INSERT INTO `allqua` VALUES ('1805090221', NULL, NULL, NULL);
INSERT INTO `allqua` VALUES ('1805100214', NULL, NULL, NULL);
INSERT INTO `allqua` VALUES ('1805100341', NULL, NULL, NULL);
INSERT INTO `allqua` VALUES ('1806070417', NULL, NULL, NULL);
INSERT INTO `allqua` VALUES ('1807090414', NULL, NULL, NULL);
INSERT INTO `allqua` VALUES ('1810080435', NULL, NULL, NULL);
INSERT INTO `allqua` VALUES ('1811060137', NULL, NULL, NULL);
INSERT INTO `allqua` VALUES ('1812190202', NULL, NULL, NULL);
INSERT INTO `allqua` VALUES ('1812190208', 10.0, 10.0, 1.0);
INSERT INTO `allqua` VALUES ('1812190210', NULL, NULL, NULL);
INSERT INTO `allqua` VALUES ('1812190218', NULL, NULL, NULL);
INSERT INTO `allqua` VALUES ('1812190219', NULL, NULL, NULL);
INSERT INTO `allqua` VALUES ('1812190220', NULL, NULL, NULL);
INSERT INTO `allqua` VALUES ('1812190224', NULL, NULL, NULL);
INSERT INTO `allqua` VALUES ('1812190226', NULL, NULL, NULL);
INSERT INTO `allqua` VALUES ('1812190227', NULL, NULL, NULL);
INSERT INTO `allqua` VALUES ('1812190228', NULL, NULL, NULL);
INSERT INTO `allqua` VALUES ('1812190229', NULL, NULL, NULL);
INSERT INTO `allqua` VALUES ('1812190230', NULL, NULL, NULL);
INSERT INTO `allqua` VALUES ('1812190231', NULL, NULL, NULL);
INSERT INTO `allqua` VALUES ('1812190232', NULL, NULL, NULL);
INSERT INTO `allqua` VALUES ('1812190503', NULL, NULL, NULL);
INSERT INTO `allqua` VALUES ('1812190505', NULL, NULL, NULL);
INSERT INTO `allqua` VALUES ('1812190509', NULL, NULL, NULL);
INSERT INTO `allqua` VALUES ('1812190521', NULL, NULL, NULL);
INSERT INTO `allqua` VALUES ('1812190522', NULL, NULL, NULL);
INSERT INTO `allqua` VALUES ('1812190532', NULL, NULL, NULL);
INSERT INTO `allqua` VALUES ('1819130205', NULL, NULL, NULL);
INSERT INTO `allqua` VALUES ('1820100608', NULL, NULL, NULL);
INSERT INTO `allqua` VALUES ('1820100703', NULL, NULL, NULL);
INSERT INTO `allqua` VALUES ('1822010211', NULL, NULL, NULL);
INSERT INTO `allqua` VALUES ('1823040320', NULL, NULL, NULL);
INSERT INTO `allqua` VALUES ('1835010206', NULL, NULL, NULL);
INSERT INTO `allqua` VALUES ('1835020601', NULL, NULL, NULL);

-- ----------------------------
-- Table structure for ascore
-- ----------------------------
DROP TABLE IF EXISTS `ascore`;
CREATE TABLE `ascore`  (
  `SNo` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `AScore` float(3, 1) NULL DEFAULT NULL,
  PRIMARY KEY (`SNo`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of ascore
-- ----------------------------
INSERT INTO `ascore` VALUES ('1402080224', NULL);
INSERT INTO `ascore` VALUES ('1710080232', NULL);
INSERT INTO `ascore` VALUES ('1801110602', NULL);
INSERT INTO `ascore` VALUES ('1805090112', NULL);
INSERT INTO `ascore` VALUES ('1805090221', NULL);
INSERT INTO `ascore` VALUES ('1805100214', NULL);
INSERT INTO `ascore` VALUES ('1805100341', NULL);
INSERT INTO `ascore` VALUES ('1806070417', NULL);
INSERT INTO `ascore` VALUES ('1807090414', NULL);
INSERT INTO `ascore` VALUES ('1810080435', NULL);
INSERT INTO `ascore` VALUES ('1811060137', NULL);
INSERT INTO `ascore` VALUES ('1812190202', NULL);
INSERT INTO `ascore` VALUES ('1812190208', NULL);
INSERT INTO `ascore` VALUES ('1812190210', NULL);
INSERT INTO `ascore` VALUES ('1812190218', NULL);
INSERT INTO `ascore` VALUES ('1812190219', NULL);
INSERT INTO `ascore` VALUES ('1812190220', NULL);
INSERT INTO `ascore` VALUES ('1812190224', NULL);
INSERT INTO `ascore` VALUES ('1812190226', NULL);
INSERT INTO `ascore` VALUES ('1812190227', NULL);
INSERT INTO `ascore` VALUES ('1812190228', NULL);
INSERT INTO `ascore` VALUES ('1812190229', NULL);
INSERT INTO `ascore` VALUES ('1812190230', NULL);
INSERT INTO `ascore` VALUES ('1812190231', NULL);
INSERT INTO `ascore` VALUES ('1812190232', NULL);
INSERT INTO `ascore` VALUES ('1812190503', NULL);
INSERT INTO `ascore` VALUES ('1812190505', NULL);
INSERT INTO `ascore` VALUES ('1812190509', NULL);
INSERT INTO `ascore` VALUES ('1812190521', NULL);
INSERT INTO `ascore` VALUES ('1812190522', NULL);
INSERT INTO `ascore` VALUES ('1812190532', NULL);
INSERT INTO `ascore` VALUES ('1819130205', NULL);
INSERT INTO `ascore` VALUES ('1820100608', NULL);
INSERT INTO `ascore` VALUES ('1820100703', NULL);
INSERT INTO `ascore` VALUES ('1822010211', NULL);
INSERT INTO `ascore` VALUES ('1823040320', NULL);
INSERT INTO `ascore` VALUES ('1835010206', NULL);
INSERT INTO `ascore` VALUES ('1835020601', NULL);

-- ----------------------------
-- Table structure for auth_group
-- ----------------------------
DROP TABLE IF EXISTS `auth_group`;
CREATE TABLE `auth_group`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `name`(`name`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of auth_group
-- ----------------------------

-- ----------------------------
-- Table structure for auth_group_permissions
-- ----------------------------
DROP TABLE IF EXISTS `auth_group_permissions`;
CREATE TABLE `auth_group_permissions`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `group_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `auth_group_permissions_group_id_permission_id_0cd325b0_uniq`(`group_id`, `permission_id`) USING BTREE,
  INDEX `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm`(`permission_id`) USING BTREE,
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of auth_group_permissions
-- ----------------------------

-- ----------------------------
-- Table structure for auth_permission
-- ----------------------------
DROP TABLE IF EXISTS `auth_permission`;
CREATE TABLE `auth_permission`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `content_type_id` int NOT NULL,
  `codename` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `auth_permission_content_type_id_codename_01ab375a_uniq`(`content_type_id`, `codename`) USING BTREE,
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 25 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of auth_permission
-- ----------------------------
INSERT INTO `auth_permission` VALUES (1, 'Can add log entry', 1, 'add_logentry');
INSERT INTO `auth_permission` VALUES (2, 'Can change log entry', 1, 'change_logentry');
INSERT INTO `auth_permission` VALUES (3, 'Can delete log entry', 1, 'delete_logentry');
INSERT INTO `auth_permission` VALUES (4, 'Can view log entry', 1, 'view_logentry');
INSERT INTO `auth_permission` VALUES (5, 'Can add permission', 2, 'add_permission');
INSERT INTO `auth_permission` VALUES (6, 'Can change permission', 2, 'change_permission');
INSERT INTO `auth_permission` VALUES (7, 'Can delete permission', 2, 'delete_permission');
INSERT INTO `auth_permission` VALUES (8, 'Can view permission', 2, 'view_permission');
INSERT INTO `auth_permission` VALUES (9, 'Can add group', 3, 'add_group');
INSERT INTO `auth_permission` VALUES (10, 'Can change group', 3, 'change_group');
INSERT INTO `auth_permission` VALUES (11, 'Can delete group', 3, 'delete_group');
INSERT INTO `auth_permission` VALUES (12, 'Can view group', 3, 'view_group');
INSERT INTO `auth_permission` VALUES (13, 'Can add user', 4, 'add_user');
INSERT INTO `auth_permission` VALUES (14, 'Can change user', 4, 'change_user');
INSERT INTO `auth_permission` VALUES (15, 'Can delete user', 4, 'delete_user');
INSERT INTO `auth_permission` VALUES (16, 'Can view user', 4, 'view_user');
INSERT INTO `auth_permission` VALUES (17, 'Can add content type', 5, 'add_contenttype');
INSERT INTO `auth_permission` VALUES (18, 'Can change content type', 5, 'change_contenttype');
INSERT INTO `auth_permission` VALUES (19, 'Can delete content type', 5, 'delete_contenttype');
INSERT INTO `auth_permission` VALUES (20, 'Can view content type', 5, 'view_contenttype');
INSERT INTO `auth_permission` VALUES (21, 'Can add session', 6, 'add_session');
INSERT INTO `auth_permission` VALUES (22, 'Can change session', 6, 'change_session');
INSERT INTO `auth_permission` VALUES (23, 'Can delete session', 6, 'delete_session');
INSERT INTO `auth_permission` VALUES (24, 'Can view session', 6, 'view_session');
INSERT INTO `auth_permission` VALUES (25, 'Can add admin signin', 7, 'add_adminsignin');
INSERT INTO `auth_permission` VALUES (26, 'Can change admin signin', 7, 'change_adminsignin');
INSERT INTO `auth_permission` VALUES (27, 'Can delete admin signin', 7, 'delete_adminsignin');
INSERT INTO `auth_permission` VALUES (28, 'Can view admin signin', 7, 'view_adminsignin');
INSERT INTO `auth_permission` VALUES (29, 'Can add allability', 8, 'add_allability');
INSERT INTO `auth_permission` VALUES (30, 'Can change allability', 8, 'change_allability');
INSERT INTO `auth_permission` VALUES (31, 'Can delete allability', 8, 'delete_allability');
INSERT INTO `auth_permission` VALUES (32, 'Can view allability', 8, 'view_allability');
INSERT INTO `auth_permission` VALUES (33, 'Can add allqua', 9, 'add_allqua');
INSERT INTO `auth_permission` VALUES (34, 'Can change allqua', 9, 'change_allqua');
INSERT INTO `auth_permission` VALUES (35, 'Can delete allqua', 9, 'delete_allqua');
INSERT INTO `auth_permission` VALUES (36, 'Can view allqua', 9, 'view_allqua');
INSERT INTO `auth_permission` VALUES (37, 'Can add ascore', 10, 'add_ascore');
INSERT INTO `auth_permission` VALUES (38, 'Can change ascore', 10, 'change_ascore');
INSERT INTO `auth_permission` VALUES (39, 'Can delete ascore', 10, 'delete_ascore');
INSERT INTO `auth_permission` VALUES (40, 'Can view ascore', 10, 'view_ascore');
INSERT INTO `auth_permission` VALUES (41, 'Can add cadres', 11, 'add_cadres');
INSERT INTO `auth_permission` VALUES (42, 'Can change cadres', 11, 'change_cadres');
INSERT INTO `auth_permission` VALUES (43, 'Can delete cadres', 11, 'delete_cadres');
INSERT INTO `auth_permission` VALUES (44, 'Can view cadres', 11, 'view_cadres');
INSERT INTO `auth_permission` VALUES (45, 'Can add cadres1', 12, 'add_cadres1');
INSERT INTO `auth_permission` VALUES (46, 'Can change cadres1', 12, 'change_cadres1');
INSERT INTO `auth_permission` VALUES (47, 'Can delete cadres1', 12, 'delete_cadres1');
INSERT INTO `auth_permission` VALUES (48, 'Can view cadres1', 12, 'view_cadres1');
INSERT INTO `auth_permission` VALUES (49, 'Can add chooselesson', 13, 'add_chooselesson');
INSERT INTO `auth_permission` VALUES (50, 'Can change chooselesson', 13, 'change_chooselesson');
INSERT INTO `auth_permission` VALUES (51, 'Can delete chooselesson', 13, 'delete_chooselesson');
INSERT INTO `auth_permission` VALUES (52, 'Can view chooselesson', 13, 'view_chooselesson');
INSERT INTO `auth_permission` VALUES (53, 'Can add club', 14, 'add_club');
INSERT INTO `auth_permission` VALUES (54, 'Can change club', 14, 'change_club');
INSERT INTO `auth_permission` VALUES (55, 'Can delete club', 14, 'delete_club');
INSERT INTO `auth_permission` VALUES (56, 'Can view club', 14, 'view_club');
INSERT INTO `auth_permission` VALUES (57, 'Can add deduct', 15, 'add_deduct');
INSERT INTO `auth_permission` VALUES (58, 'Can change deduct', 15, 'change_deduct');
INSERT INTO `auth_permission` VALUES (59, 'Can delete deduct', 15, 'delete_deduct');
INSERT INTO `auth_permission` VALUES (60, 'Can view deduct', 15, 'view_deduct');
INSERT INTO `auth_permission` VALUES (61, 'Can add deduct1', 16, 'add_deduct1');
INSERT INTO `auth_permission` VALUES (62, 'Can change deduct1', 16, 'change_deduct1');
INSERT INTO `auth_permission` VALUES (63, 'Can delete deduct1', 16, 'delete_deduct1');
INSERT INTO `auth_permission` VALUES (64, 'Can view deduct1', 16, 'view_deduct1');
INSERT INTO `auth_permission` VALUES (65, 'Can add django migrations', 17, 'add_djangomigrations');
INSERT INTO `auth_permission` VALUES (66, 'Can change django migrations', 17, 'change_djangomigrations');
INSERT INTO `auth_permission` VALUES (67, 'Can delete django migrations', 17, 'delete_djangomigrations');
INSERT INTO `auth_permission` VALUES (68, 'Can view django migrations', 17, 'view_djangomigrations');
INSERT INTO `auth_permission` VALUES (69, 'Can add groupadd', 18, 'add_groupadd');
INSERT INTO `auth_permission` VALUES (70, 'Can change groupadd', 18, 'change_groupadd');
INSERT INTO `auth_permission` VALUES (71, 'Can delete groupadd', 18, 'delete_groupadd');
INSERT INTO `auth_permission` VALUES (72, 'Can view groupadd', 18, 'view_groupadd');
INSERT INTO `auth_permission` VALUES (73, 'Can add groupadd1', 19, 'add_groupadd1');
INSERT INTO `auth_permission` VALUES (74, 'Can change groupadd1', 19, 'change_groupadd1');
INSERT INTO `auth_permission` VALUES (75, 'Can delete groupadd1', 19, 'delete_groupadd1');
INSERT INTO `auth_permission` VALUES (76, 'Can view groupadd1', 19, 'view_groupadd1');
INSERT INTO `auth_permission` VALUES (77, 'Can add lesson', 20, 'add_lesson');
INSERT INTO `auth_permission` VALUES (78, 'Can change lesson', 20, 'change_lesson');
INSERT INTO `auth_permission` VALUES (79, 'Can delete lesson', 20, 'delete_lesson');
INSERT INTO `auth_permission` VALUES (80, 'Can view lesson', 20, 'view_lesson');
INSERT INTO `auth_permission` VALUES (81, 'Can add manager', 21, 'add_manager');
INSERT INTO `auth_permission` VALUES (82, 'Can change manager', 21, 'change_manager');
INSERT INTO `auth_permission` VALUES (83, 'Can delete manager', 21, 'delete_manager');
INSERT INTO `auth_permission` VALUES (84, 'Can view manager', 21, 'view_manager');
INSERT INTO `auth_permission` VALUES (85, 'Can add personaladd', 22, 'add_personaladd');
INSERT INTO `auth_permission` VALUES (86, 'Can change personaladd', 22, 'change_personaladd');
INSERT INTO `auth_permission` VALUES (87, 'Can delete personaladd', 22, 'delete_personaladd');
INSERT INTO `auth_permission` VALUES (88, 'Can view personaladd', 22, 'view_personaladd');
INSERT INTO `auth_permission` VALUES (89, 'Can add personaladd1', 23, 'add_personaladd1');
INSERT INTO `auth_permission` VALUES (90, 'Can change personaladd1', 23, 'change_personaladd1');
INSERT INTO `auth_permission` VALUES (91, 'Can delete personaladd1', 23, 'delete_personaladd1');
INSERT INTO `auth_permission` VALUES (92, 'Can view personaladd1', 23, 'view_personaladd1');
INSERT INTO `auth_permission` VALUES (93, 'Can add proskill', 24, 'add_proskill');
INSERT INTO `auth_permission` VALUES (94, 'Can change proskill', 24, 'change_proskill');
INSERT INTO `auth_permission` VALUES (95, 'Can delete proskill', 24, 'delete_proskill');
INSERT INTO `auth_permission` VALUES (96, 'Can view proskill', 24, 'view_proskill');
INSERT INTO `auth_permission` VALUES (97, 'Can add proskill1', 25, 'add_proskill1');
INSERT INTO `auth_permission` VALUES (98, 'Can change proskill1', 25, 'change_proskill1');
INSERT INTO `auth_permission` VALUES (99, 'Can delete proskill1', 25, 'delete_proskill1');
INSERT INTO `auth_permission` VALUES (100, 'Can view proskill1', 25, 'view_proskill1');
INSERT INTO `auth_permission` VALUES (101, 'Can add qscore', 26, 'add_qscore');
INSERT INTO `auth_permission` VALUES (102, 'Can change qscore', 26, 'change_qscore');
INSERT INTO `auth_permission` VALUES (103, 'Can delete qscore', 26, 'delete_qscore');
INSERT INTO `auth_permission` VALUES (104, 'Can view qscore', 26, 'view_qscore');
INSERT INTO `auth_permission` VALUES (105, 'Can add research', 27, 'add_research');
INSERT INTO `auth_permission` VALUES (106, 'Can change research', 27, 'change_research');
INSERT INTO `auth_permission` VALUES (107, 'Can delete research', 27, 'delete_research');
INSERT INTO `auth_permission` VALUES (108, 'Can view research', 27, 'view_research');
INSERT INTO `auth_permission` VALUES (109, 'Can add research1', 28, 'add_research1');
INSERT INTO `auth_permission` VALUES (110, 'Can change research1', 28, 'change_research1');
INSERT INTO `auth_permission` VALUES (111, 'Can delete research1', 28, 'delete_research1');
INSERT INTO `auth_permission` VALUES (112, 'Can view research1', 28, 'view_research1');
INSERT INTO `auth_permission` VALUES (113, 'Can add signin', 29, 'add_signin');
INSERT INTO `auth_permission` VALUES (114, 'Can change signin', 29, 'change_signin');
INSERT INTO `auth_permission` VALUES (115, 'Can delete signin', 29, 'delete_signin');
INSERT INTO `auth_permission` VALUES (116, 'Can view signin', 29, 'view_signin');
INSERT INTO `auth_permission` VALUES (117, 'Can add sinfo', 30, 'add_sinfo');
INSERT INTO `auth_permission` VALUES (118, 'Can change sinfo', 30, 'change_sinfo');
INSERT INTO `auth_permission` VALUES (119, 'Can delete sinfo', 30, 'delete_sinfo');
INSERT INTO `auth_permission` VALUES (120, 'Can view sinfo', 30, 'view_sinfo');
INSERT INTO `auth_permission` VALUES (121, 'Can add social', 31, 'add_social');
INSERT INTO `auth_permission` VALUES (122, 'Can change social', 31, 'change_social');
INSERT INTO `auth_permission` VALUES (123, 'Can delete social', 31, 'delete_social');
INSERT INTO `auth_permission` VALUES (124, 'Can view social', 31, 'view_social');
INSERT INTO `auth_permission` VALUES (125, 'Can add social1', 32, 'add_social1');
INSERT INTO `auth_permission` VALUES (126, 'Can change social1', 32, 'change_social1');
INSERT INTO `auth_permission` VALUES (127, 'Can delete social1', 32, 'delete_social1');
INSERT INTO `auth_permission` VALUES (128, 'Can view social1', 32, 'view_social1');
INSERT INTO `auth_permission` VALUES (129, 'Can add sports', 33, 'add_sports');
INSERT INTO `auth_permission` VALUES (130, 'Can change sports', 33, 'change_sports');
INSERT INTO `auth_permission` VALUES (131, 'Can delete sports', 33, 'delete_sports');
INSERT INTO `auth_permission` VALUES (132, 'Can view sports', 33, 'view_sports');
INSERT INTO `auth_permission` VALUES (133, 'Can add sports1', 34, 'add_sports1');
INSERT INTO `auth_permission` VALUES (134, 'Can change sports1', 34, 'change_sports1');
INSERT INTO `auth_permission` VALUES (135, 'Can delete sports1', 34, 'delete_sports1');
INSERT INTO `auth_permission` VALUES (136, 'Can view sports1', 34, 'view_sports1');

-- ----------------------------
-- Table structure for auth_user
-- ----------------------------
DROP TABLE IF EXISTS `auth_user`;
CREATE TABLE `auth_user`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `password` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `last_login` datetime(6) NULL DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `first_name` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `last_name` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `email` varchar(254) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `username`(`username`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of auth_user
-- ----------------------------

-- ----------------------------
-- Table structure for auth_user_groups
-- ----------------------------
DROP TABLE IF EXISTS `auth_user_groups`;
CREATE TABLE `auth_user_groups`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `group_id` int NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `auth_user_groups_user_id_group_id_94350c0c_uniq`(`user_id`, `group_id`) USING BTREE,
  INDEX `auth_user_groups_group_id_97559544_fk_auth_group_id`(`group_id`) USING BTREE,
  CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of auth_user_groups
-- ----------------------------

-- ----------------------------
-- Table structure for auth_user_user_permissions
-- ----------------------------
DROP TABLE IF EXISTS `auth_user_user_permissions`;
CREATE TABLE `auth_user_user_permissions`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq`(`user_id`, `permission_id`) USING BTREE,
  INDEX `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm`(`permission_id`) USING BTREE,
  CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of auth_user_user_permissions
-- ----------------------------

-- ----------------------------
-- Table structure for cadres
-- ----------------------------
DROP TABLE IF EXISTS `cadres`;
CREATE TABLE `cadres`  (
  `C_NUM` int NOT NULL,
  `C_Item` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `C_Score` float(3, 1) NULL DEFAULT NULL,
  PRIMARY KEY (`C_NUM`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of cadres
-- ----------------------------
INSERT INTO `cadres` VALUES (1, '所在班级被评为学风特优班或者优良学风班的，且个人年度工作考核定为优秀', 20.0);
INSERT INTO `cadres` VALUES (2, '所在班级被评为学风特优班或者优良学风班的，且个人年度工作考核定为良好', 15.0);
INSERT INTO `cadres` VALUES (3, '所在班级被评为学风特优班或者优良学风班的，且个人年度工作考核定为称职', 12.0);
INSERT INTO `cadres` VALUES (4, '所在班级未被评上优良学风班的，但个人年度工作考核定为优秀', 16.0);
INSERT INTO `cadres` VALUES (5, '所在班级未被评上优良学风班的，但个人年度工作考核定为良好', 13.0);
INSERT INTO `cadres` VALUES (6, '所在班级未被评上优良学风班的，但个人年度工作考核定为称职', 8.0);
INSERT INTO `cadres` VALUES (7, '所在班级学风评估成绩列学院后10%，但个人年度工作考核定为优秀', 15.0);
INSERT INTO `cadres` VALUES (8, '所在班级学风评估成绩列学院后10%，但个人年度工作考核定为良好', 12.0);
INSERT INTO `cadres` VALUES (9, '所在班级学风评估成绩列学院后10%，但个人年度工作考核定为称职', 8.0);
INSERT INTO `cadres` VALUES (10, '未列入校团委考核名单的学生会及社团干事等进行院内考核，优秀', 10.0);
INSERT INTO `cadres` VALUES (11, '未列入校团委考核名单的学生会及社团干事等进行院内考核，良好', 8.0);
INSERT INTO `cadres` VALUES (12, '未列入校团委考核名单的学生会及社团干事等进行院内考核，称职', 6.0);

-- ----------------------------
-- Table structure for cadres1
-- ----------------------------
DROP TABLE IF EXISTS `cadres1`;
CREATE TABLE `cadres1`  (
  `SNo` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `C_Num` int NOT NULL,
  `C_Prove` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `C_isTrue` varchar(6) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `C_Score` float(3, 1) NULL DEFAULT NULL,
  PRIMARY KEY (`SNo`, `C_Num`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of cadres1
-- ----------------------------

-- ----------------------------
-- Table structure for chooselesson
-- ----------------------------
DROP TABLE IF EXISTS `chooselesson`;
CREATE TABLE `chooselesson`  (
  `SNo` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `LName` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Score` float(3, 1) NULL DEFAULT NULL,
  `LSign` varchar(2) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `LExam` varchar(4) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  PRIMARY KEY (`SNo`, `LName`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of chooselesson
-- ----------------------------
INSERT INTO `chooselesson` VALUES ('1402080224', 'Windows程序设计', 48.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1402080224', '大学物理(下)', 55.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1402080224', '大学生职业生涯与发展规划', 81.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1402080224', '大学英语(四)', 80.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1402080224', '数字逻辑', 11.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1402080224', '数字逻辑实验', 42.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1402080224', '数学建模与MATLAB', 51.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1402080224', '概率论与数理统计', 51.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1402080224', '线性代数(理)', 51.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1402080224', '面向对象程序设计', 74.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1402080224', '面向对象程序设计实验', 35.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1805090221', 'Java程序设计', 76.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1805090221', '大学物理(下)', 75.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1805090221', '大学生职业生涯与发展规划', 89.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1805090221', '大学英语(四)', 87.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1805090221', '数字逻辑', 79.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1805090221', '数字逻辑实验', 83.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1805090221', '数学建模与MATLAB', 76.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1805090221', '概率论与数理统计', 82.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1805090221', '线性代数(理)', 83.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1805090221', '面向对象程序设计', 88.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1805090221', '面向对象程序设计实验', 80.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1805090221', '高级语言程序设计', 74.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1805090221', '高级语言程序设计实验', 77.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1805100214', 'Java程序设计', 91.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1805100214', '大学物理(下)', 77.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1805100214', '大学生职业生涯与发展规划', 89.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1805100214', '大学英语(四)', 86.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1805100214', '数字逻辑', 61.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1805100214', '数字逻辑实验', 94.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1805100214', '数学建模与MATLAB', 60.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1805100214', '概率论与数理统计', 60.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1805100214', '线性代数(理)', 49.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1805100214', '计算机大类专业导论', 81.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1805100214', '面向对象程序设计', 73.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1805100214', '面向对象程序设计实验', 64.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1805100214', '高级语言程序设计实验', 38.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1805100341', 'Java程序设计', 85.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1805100341', '大学物理(下)', 73.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1805100341', '大学生职业生涯与发展规划', 90.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1805100341', '大学英语(四)', 84.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1805100341', '数字逻辑', 66.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1805100341', '数字逻辑实验', 79.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1805100341', '数学建模与MATLAB', 73.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1805100341', '概率论与数理统计', 82.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1805100341', '线性代数(理)', 68.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1805100341', '面向对象程序设计', 82.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1805100341', '面向对象程序设计实验', 80.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1806070417', 'Windows程序设计', 61.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1806070417', '大学物理(下)', 85.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1806070417', '大学生职业生涯与发展规划', 89.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1806070417', '大学英语(四)', 80.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1806070417', '数字逻辑', 81.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1806070417', '数字逻辑实验', 84.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1806070417', '数学建模与MATLAB', 95.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1806070417', '概率论与数理统计', 80.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1806070417', '线性代数(理)', 82.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1806070417', '面向对象程序设计', 81.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1807090414', 'Java程序设计', 85.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1807090414', '大学物理(下)', 96.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1807090414', '大学生职业生涯与发展规划', 88.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1807090414', '大学英语(四)', 81.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1807090414', '数字逻辑', 76.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1807090414', '数字逻辑实验', 89.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1807090414', '数学建模与MATLAB', 95.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1807090414', '概率论与数理统计', 83.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1807090414', '线性代数(理)', 79.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1807090414', '面向对象程序设计实验', 94.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1807090414', '高等数学II(上)', 77.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1810080435', 'Java程序设计', 86.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1810080435', '大学物理(下)', 89.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1810080435', '大学生职业生涯与发展规划', 94.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1810080435', '大学英语(四)', 87.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1810080435', '数字逻辑', 84.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1810080435', '数字逻辑实验', 94.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1810080435', '数学建模与MATLAB', 72.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1810080435', '概率论与数理统计', 86.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1810080435', '线性代数(理)', 86.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1810080435', '面向对象程序设计', 89.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1810080435', '面向对象程序设计实验', 84.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1811060137', 'Windows程序设计', 70.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1811060137', '大学物理(下)', 88.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1811060137', '大学生职业生涯与发展规划', 88.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1811060137', '大学英语(四)', 82.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1811060137', '数字逻辑', 82.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1811060137', '数字逻辑实验', 86.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1811060137', '数学建模与MATLAB', 69.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1811060137', '概率论与数理统计', 74.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1811060137', '线性代数(理)', 79.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1811060137', '面向对象程序设计', 69.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1811060137', '面向对象程序设计实验', 90.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190202', 'Java程序设计', 76.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190202', '大学物理(下)', 44.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190202', '大学生职业生涯与发展规划', 83.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190202', '大学英语(四)', 80.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190202', '数字逻辑', 72.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190202', '数字逻辑实验', 66.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190202', '数学建模与MATLAB', 66.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190202', '概率论与数理统计', 74.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190202', '线性代数(理)', 68.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190202', '面向对象程序设计', 76.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190202', '面向对象程序设计实验', 73.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190208', 'Windows程序设计', 82.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190208', '大学物理(下)', 60.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190208', '大学生职业生涯与发展规划', 94.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190208', '大学英语(四)', 78.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190208', '数字逻辑', 62.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190208', '数字逻辑实验', 89.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190208', '数学建模与MATLAB', 80.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190208', '概率论与数理统计', 66.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190208', '线性代数(理)', 68.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190208', '面向对象程序设计', 84.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190208', '面向对象程序设计实验', 87.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190210', 'Java程序设计', 71.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190210', '大学物理(下)', 60.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190210', '大学生职业生涯与发展规划', 91.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190210', '大学英语(四)', 77.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190210', '数字逻辑', 74.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190210', '数字逻辑实验', 73.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190210', '数学建模与MATLAB', 60.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190210', '概率论与数理统计', 69.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190210', '线性代数(理)', 53.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190210', '面向对象程序设计', 64.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190210', '面向对象程序设计实验', 85.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190218', 'Windows程序设计', 78.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190218', '大学物理(下)', 69.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190218', '大学生职业生涯与发展规划', 90.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190218', '大学英语(四)', 76.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190218', '数字逻辑', 70.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190218', '数字逻辑实验', 71.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190218', '数学建模与MATLAB', 61.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190218', '概率论与数理统计', 65.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190218', '线性代数(理)', 83.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190218', '面向对象程序设计', 76.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190218', '面向对象程序设计实验', 64.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190219', 'Windows程序设计', 88.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190219', '大学物理(下)', 86.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190219', '大学生职业生涯与发展规划', 94.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190219', '大学英语(四)', 81.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190219', '数字逻辑', 89.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190219', '数字逻辑实验', 89.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190219', '数学建模与MATLAB', 89.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190219', '概率论与数理统计', 93.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190219', '线性代数(理)', 95.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190219', '面向对象程序设计', 91.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190219', '面向对象程序设计实验', 80.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190220', 'Java程序设计', 85.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190220', '大学物理(下)', 88.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190220', '大学生职业生涯与发展规划', 89.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190220', '大学英语(四)', 84.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190220', '数字逻辑', 77.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190220', '数字逻辑实验', 92.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190220', '数学建模与MATLAB', 68.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190220', '概率论与数理统计', 62.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190220', '线性代数(理)', 67.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190220', '面向对象程序设计', 80.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190220', '面向对象程序设计实验', 88.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190226', 'Windows程序设计', 94.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190226', '大学物理(下)', 88.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190226', '大学生职业生涯与发展规划', 93.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190226', '大学英语(四)', 87.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190226', '数字逻辑', 88.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190226', '数字逻辑实验', 89.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190226', '数学建模与MATLAB', 82.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190226', '概率论与数理统计', 89.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190226', '线性代数(理)', 90.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190226', '面向对象程序设计', 93.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190226', '面向对象程序设计实验', 99.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190227', 'Windows程序设计', 77.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190227', '大学物理(下)', 88.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190227', '大学生职业生涯与发展规划', 87.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190227', '大学英语(四)', 90.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190227', '数字逻辑', 73.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190227', '数字逻辑实验', 70.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190227', '数学建模与MATLAB', 78.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190227', '概率论与数理统计', 85.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190227', '线性代数(理)', 79.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190227', '面向对象程序设计', 87.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190227', '面向对象程序设计实验', 69.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190228', 'Windows程序设计', 85.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190228', '大学物理(下)', 87.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190228', '大学生职业生涯与发展规划', 91.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190228', '大学英语(四)', 84.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190228', '数字逻辑', 89.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190228', '数字逻辑实验', 84.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190228', '数学建模与MATLAB', 82.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190228', '概率论与数理统计', 86.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190228', '线性代数(理)', 87.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190228', '面向对象程序设计', 84.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190228', '面向对象程序设计实验', 89.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190229', 'Windows程序设计', 75.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190229', '大学物理(下)', 71.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190229', '大学生职业生涯与发展规划', 89.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190229', '大学英语(四)', 72.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190229', '数字逻辑', 68.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190229', '数字逻辑实验', 87.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190229', '数学建模与MATLAB', 69.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190229', '概率论与数理统计', 61.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190229', '线性代数(理)', 47.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190229', '面向对象程序设计', 70.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190229', '面向对象程序设计实验', 72.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190232', 'Windows程序设计', 89.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190232', '大学物理(下)', 99.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190232', '大学生职业生涯与发展规划', 85.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190232', '大学英语(四)', 86.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190232', '数字逻辑', 86.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190232', '数字逻辑实验', 93.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190232', '数学建模与MATLAB', 95.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190232', '概率论与数理统计', 82.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190232', '线性代数(理)', 89.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190232', '面向对象程序设计', 91.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190232', '面向对象程序设计实验', 83.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190503', 'Java程序设计', 88.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190503', '大学物理(下)', 90.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190503', '大学生职业生涯与发展规划', 85.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190503', '大学英语(四)', 69.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190503', '数字逻辑', 66.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190503', '数字逻辑实验', 95.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190503', '数学建模与MATLAB', 88.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190503', '概率论与数理统计', 80.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190503', '线性代数(理)', 73.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190503', '面向对象程序设计', 80.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190503', '面向对象程序设计实验', 83.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190505', 'Java程序设计', 82.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190505', '大学物理(下)', 76.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190505', '大学生职业生涯与发展规划', 94.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190505', '大学英语(四)', 84.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190505', '数字逻辑', 60.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190505', '数字逻辑实验', 81.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190505', '数学建模与MATLAB', 75.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190505', '概率论与数理统计', 71.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190505', '线性代数(理)', 67.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190505', '面向对象程序设计', 78.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190505', '面向对象程序设计实验', 73.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190509', 'Windows程序设计', 77.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190509', '大学物理(下)', 97.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190509', '大学生职业生涯与发展规划', 89.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190509', '大学英语(四)', 78.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190509', '数字逻辑', 66.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190509', '数字逻辑实验', 73.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190509', '数学建模与MATLAB', 65.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190509', '概率论与数理统计', 63.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190509', '线性代数(理)', 67.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190509', '面向对象程序设计', 75.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190509', '面向对象程序设计实验', 68.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190521', 'Windows程序设计', 79.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190521', '大学物理(下)', 85.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190521', '大学生职业生涯与发展规划', 94.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190521', '大学英语(四)', 85.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190521', '数字逻辑', 75.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190521', '数字逻辑实验', 73.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190521', '数学建模与MATLAB', 87.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190521', '概率论与数理统计', 84.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190521', '线性代数(理)', 85.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190521', '面向对象程序设计', 91.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190521', '面向对象程序设计实验', 99.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190522', 'Java程序设计', 85.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190522', '大学物理(下)', 82.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190522', '大学生职业生涯与发展规划', 89.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190522', '大学英语(四)', 84.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190522', '数字逻辑', 80.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190522', '数字逻辑实验', 86.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190522', '数学建模与MATLAB', 75.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190522', '概率论与数理统计', 67.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190522', '线性代数(理)', 72.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190522', '面向对象程序设计', 73.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1812190522', '面向对象程序设计实验', 72.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1822010211', 'Windows程序设计', 79.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1822010211', '大学物理(下)', 76.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1822010211', '大学生职业生涯与发展规划', 87.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1822010211', '大学英语(四)', 80.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1822010211', '数字逻辑', 63.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1822010211', '数字逻辑实验', 77.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1822010211', '数学建模与MATLAB', 60.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1822010211', '概率论与数理统计', 73.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1822010211', '线性代数(理)', 87.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1822010211', '面向对象程序设计', 82.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1822010211', '面向对象程序设计实验', 69.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1823040320', 'Windows程序设计', 85.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1823040320', '大学物理(下)', 90.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1823040320', '大学生职业生涯与发展规划', 88.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1823040320', '大学英语(四)', 88.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1823040320', '数字逻辑', 85.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1823040320', '数字逻辑实验', 76.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1823040320', '数学建模与MATLAB', 87.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1823040320', '概率论与数理统计', 83.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1823040320', '线性代数(理)', 81.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1823040320', '面向对象程序设计', 85.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1823040320', '面向对象程序设计实验', 82.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1835010206', 'Java程序设计', 78.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1835010206', '大学物理(下)', 60.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1835010206', '大学生职业生涯与发展规划', 94.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1835010206', '大学英语(四)', 84.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1835010206', '数字逻辑', 74.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1835010206', '数字逻辑实验', 71.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1835010206', '数学建模与MATLAB', 60.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1835010206', '概率论与数理统计', 52.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1835010206', '线性代数(理)', 57.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1835010206', '计算机大类专业导论', 73.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1835010206', '面向对象程序设计', 78.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1835010206', '面向对象程序设计实验', 65.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1835020601', '大学物理(下)', 60.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1835020601', '大学生职业生涯与发展规划', 86.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1835020601', '大学英语(四)', 73.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1835020601', '数字逻辑', 66.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1835020601', '数字逻辑实验', 81.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1835020601', '数学建模与MATLAB', 68.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1835020601', '概率论与数理统计', 54.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1835020601', '线性代数(理)', 65.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1835020601', '面向对象程序设计', 87.0, '主修', '正常考试');
INSERT INTO `chooselesson` VALUES ('1835020601', '面向对象程序设计实验', 92.0, '主修', '正常考试');

-- ----------------------------
-- Table structure for club
-- ----------------------------
DROP TABLE IF EXISTS `club`;
CREATE TABLE `club`  (
  `SNo` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `CName` varchar(8) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Post` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  PRIMARY KEY (`SNo`, `CName`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of club
-- ----------------------------
INSERT INTO `club` VALUES ('1812190208', '学生会', '部长');

-- ----------------------------
-- Table structure for deduct
-- ----------------------------
DROP TABLE IF EXISTS `deduct`;
CREATE TABLE `deduct`  (
  `D_NUM` int NOT NULL,
  `D_Item` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `D_Score` float(3, 1) NULL DEFAULT NULL,
  PRIMARY KEY (`D_NUM`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of deduct
-- ----------------------------
INSERT INTO `deduct` VALUES (1, '未按学校、学院规定时间参加各类讲座、会议及其他安排且未事先办理请假手续者', 1.0);
INSERT INTO `deduct` VALUES (2, '未按学校、学院规定时间参加各类讲座、会议及其他安排迟到者', 0.5);
INSERT INTO `deduct` VALUES (3, '正常教学安排（含早、晚自习）中无故旷课或缺席者', 2.0);
INSERT INTO `deduct` VALUES (4, '正常教学安排（含早、晚自习）中迟到者', 1.0);
INSERT INTO `deduct` VALUES (5, '班级早自习纪律较差的，每查到一次班级每个成员', 1.0);
INSERT INTO `deduct` VALUES (6, '未按学校规定日期到校报到且未事先办理请假手续者', 1.0);
INSERT INTO `deduct` VALUES (7, '未按学校规定日期到校报到且未事先办理请假手续有虚报者，被查实', 2.0);
INSERT INTO `deduct` VALUES (8, '受学院通报批评者', 1.0);
INSERT INTO `deduct` VALUES (9, '受学校通报批评者', 2.0);
INSERT INTO `deduct` VALUES (10, '受校（院）警告、严重警告处分者', 4.0);
INSERT INTO `deduct` VALUES (11, '受校（院）记过处分者', 8.0);
INSERT INTO `deduct` VALUES (12, '受校留校察看者', 10.0);
INSERT INTO `deduct` VALUES (13, '寝室内常规检查、随机抽查的不文明、违反规定用火用电等现象', 1.0);
INSERT INTO `deduct` VALUES (14, '晚自习期间寝室熄灯违规每次', 0.5);
INSERT INTO `deduct` VALUES (15, '晚自习期间寝室熄灯违规3次以上后每次', 1.0);

-- ----------------------------
-- Table structure for deduct1
-- ----------------------------
DROP TABLE IF EXISTS `deduct1`;
CREATE TABLE `deduct1`  (
  `SNo` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `D_Num` int NOT NULL,
  `D_Prove` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `D_isTrue` varchar(6) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `D_Score` float(3, 1) NULL DEFAULT NULL,
  PRIMARY KEY (`SNo`, `D_Num`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of deduct1
-- ----------------------------

-- ----------------------------
-- Table structure for django_admin_log
-- ----------------------------
DROP TABLE IF EXISTS `django_admin_log`;
CREATE TABLE `django_admin_log`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `object_repr` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `action_flag` smallint UNSIGNED NOT NULL,
  `change_message` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `content_type_id` int NULL DEFAULT NULL,
  `user_id` int NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `django_admin_log_content_type_id_c4bce8eb_fk_django_co`(`content_type_id`) USING BTREE,
  INDEX `django_admin_log_user_id_c564eba6_fk_auth_user_id`(`user_id`) USING BTREE,
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of django_admin_log
-- ----------------------------

-- ----------------------------
-- Table structure for django_content_type
-- ----------------------------
DROP TABLE IF EXISTS `django_content_type`;
CREATE TABLE `django_content_type`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `model` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `django_content_type_app_label_model_76bd3d3b_uniq`(`app_label`, `model`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of django_content_type
-- ----------------------------
INSERT INTO `django_content_type` VALUES (1, 'admin', 'logentry');
INSERT INTO `django_content_type` VALUES (3, 'auth', 'group');
INSERT INTO `django_content_type` VALUES (2, 'auth', 'permission');
INSERT INTO `django_content_type` VALUES (4, 'auth', 'user');
INSERT INTO `django_content_type` VALUES (5, 'contenttypes', 'contenttype');
INSERT INTO `django_content_type` VALUES (7, 'pages', 'adminsignin');
INSERT INTO `django_content_type` VALUES (8, 'pages', 'allability');
INSERT INTO `django_content_type` VALUES (9, 'pages', 'allqua');
INSERT INTO `django_content_type` VALUES (10, 'pages', 'ascore');
INSERT INTO `django_content_type` VALUES (11, 'pages', 'cadres');
INSERT INTO `django_content_type` VALUES (12, 'pages', 'cadres1');
INSERT INTO `django_content_type` VALUES (13, 'pages', 'chooselesson');
INSERT INTO `django_content_type` VALUES (14, 'pages', 'club');
INSERT INTO `django_content_type` VALUES (15, 'pages', 'deduct');
INSERT INTO `django_content_type` VALUES (16, 'pages', 'deduct1');
INSERT INTO `django_content_type` VALUES (17, 'pages', 'djangomigrations');
INSERT INTO `django_content_type` VALUES (18, 'pages', 'groupadd');
INSERT INTO `django_content_type` VALUES (19, 'pages', 'groupadd1');
INSERT INTO `django_content_type` VALUES (20, 'pages', 'lesson');
INSERT INTO `django_content_type` VALUES (21, 'pages', 'manager');
INSERT INTO `django_content_type` VALUES (22, 'pages', 'personaladd');
INSERT INTO `django_content_type` VALUES (23, 'pages', 'personaladd1');
INSERT INTO `django_content_type` VALUES (24, 'pages', 'proskill');
INSERT INTO `django_content_type` VALUES (25, 'pages', 'proskill1');
INSERT INTO `django_content_type` VALUES (26, 'pages', 'qscore');
INSERT INTO `django_content_type` VALUES (27, 'pages', 'research');
INSERT INTO `django_content_type` VALUES (28, 'pages', 'research1');
INSERT INTO `django_content_type` VALUES (29, 'pages', 'signin');
INSERT INTO `django_content_type` VALUES (30, 'pages', 'sinfo');
INSERT INTO `django_content_type` VALUES (31, 'pages', 'social');
INSERT INTO `django_content_type` VALUES (32, 'pages', 'social1');
INSERT INTO `django_content_type` VALUES (33, 'pages', 'sports');
INSERT INTO `django_content_type` VALUES (34, 'pages', 'sports1');
INSERT INTO `django_content_type` VALUES (6, 'sessions', 'session');

-- ----------------------------
-- Table structure for django_migrations
-- ----------------------------
DROP TABLE IF EXISTS `django_migrations`;
CREATE TABLE `django_migrations`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `app` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of django_migrations
-- ----------------------------
INSERT INTO `django_migrations` VALUES (1, 'pages', '0001_initial', '2020-07-08 20:36:07.906252');
INSERT INTO `django_migrations` VALUES (2, 'contenttypes', '0001_initial', '2020-07-08 20:44:52.204193');
INSERT INTO `django_migrations` VALUES (3, 'auth', '0001_initial', '2020-07-08 20:44:52.401667');
INSERT INTO `django_migrations` VALUES (4, 'admin', '0001_initial', '2020-07-08 20:44:52.875397');
INSERT INTO `django_migrations` VALUES (5, 'admin', '0002_logentry_remove_auto_add', '2020-07-08 20:44:53.009041');
INSERT INTO `django_migrations` VALUES (6, 'admin', '0003_logentry_add_action_flag_choices', '2020-07-08 20:44:53.027990');
INSERT INTO `django_migrations` VALUES (7, 'contenttypes', '0002_remove_content_type_name', '2020-07-08 20:44:53.142684');
INSERT INTO `django_migrations` VALUES (8, 'auth', '0002_alter_permission_name_max_length', '2020-07-08 20:44:53.201527');
INSERT INTO `django_migrations` VALUES (9, 'auth', '0003_alter_user_email_max_length', '2020-07-08 20:44:53.274364');
INSERT INTO `django_migrations` VALUES (10, 'auth', '0004_alter_user_username_opts', '2020-07-08 20:44:53.285302');
INSERT INTO `django_migrations` VALUES (11, 'auth', '0005_alter_user_last_login_null', '2020-07-08 20:44:53.348136');
INSERT INTO `django_migrations` VALUES (12, 'auth', '0006_require_contenttypes_0002', '2020-07-08 20:44:53.354121');
INSERT INTO `django_migrations` VALUES (13, 'auth', '0007_alter_validators_add_error_messages', '2020-07-08 20:44:53.373067');
INSERT INTO `django_migrations` VALUES (14, 'auth', '0008_alter_user_username_max_length', '2020-07-08 20:44:53.448864');
INSERT INTO `django_migrations` VALUES (15, 'auth', '0009_alter_user_last_name_max_length', '2020-07-08 20:44:53.518680');
INSERT INTO `django_migrations` VALUES (16, 'auth', '0010_alter_group_name_max_length', '2020-07-08 20:44:53.577524');
INSERT INTO `django_migrations` VALUES (17, 'auth', '0011_update_proxy_permissions', '2020-07-08 20:44:53.594480');
INSERT INTO `django_migrations` VALUES (18, 'sessions', '0001_initial', '2020-07-08 20:44:53.621403');

-- ----------------------------
-- Table structure for django_session
-- ----------------------------
DROP TABLE IF EXISTS `django_session`;
CREATE TABLE `django_session`  (
  `session_key` varchar(40) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `session_data` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`) USING BTREE,
  INDEX `django_session_expire_date_a5c62663`(`expire_date`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of django_session
-- ----------------------------

-- ----------------------------
-- Table structure for groupadd
-- ----------------------------
DROP TABLE IF EXISTS `groupadd`;
CREATE TABLE `groupadd`  (
  `G_NUM` int NOT NULL,
  `G_Item` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `G_Score` float(3, 1) NULL DEFAULT NULL,
  PRIMARY KEY (`G_NUM`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of groupadd
-- ----------------------------
INSERT INTO `groupadd` VALUES (1, '校学风优良班一次', 5.0);
INSERT INTO `groupadd` VALUES (2, '校学风优良班两次', 8.0);
INSERT INTO `groupadd` VALUES (3, '校学风特优班', 10.0);
INSERT INTO `groupadd` VALUES (4, '校先进团支部', 5.0);
INSERT INTO `groupadd` VALUES (5, '校十佳团支部', 6.0);
INSERT INTO `groupadd` VALUES (6, '校五四团支部', 8.0);
INSERT INTO `groupadd` VALUES (7, '院优秀团支部', 2.0);
INSERT INTO `groupadd` VALUES (8, '校十佳团日活动', 4.0);
INSERT INTO `groupadd` VALUES (9, '校优秀团日活动', 2.0);
INSERT INTO `groupadd` VALUES (10, '院优秀团日活动', 1.0);

-- ----------------------------
-- Table structure for groupadd1
-- ----------------------------
DROP TABLE IF EXISTS `groupadd1`;
CREATE TABLE `groupadd1`  (
  `Monitor` varchar(4) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `G_Num` int NOT NULL,
  `SNo` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `G_Prove` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `G_isTrue` varchar(6) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `G_Score` float(3, 1) NULL DEFAULT NULL,
  PRIMARY KEY (`Monitor`, `G_Num`, `SNo`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of groupadd1
-- ----------------------------

-- ----------------------------
-- Table structure for lesson
-- ----------------------------
DROP TABLE IF EXISTS `lesson`;
CREATE TABLE `lesson`  (
  `LName` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `LType` varchar(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `LCredit` float(2, 1) NULL DEFAULT NULL,
  PRIMARY KEY (`LName`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of lesson
-- ----------------------------
INSERT INTO `lesson` VALUES ('Java程序设计', '专业核心课', 3.0);
INSERT INTO `lesson` VALUES ('Windows程序设计', '专业选修课', 3.0);
INSERT INTO `lesson` VALUES ('大学物理(下)', '学科共同课', 3.0);
INSERT INTO `lesson` VALUES ('大学生职业生涯与发展规划', '普通共同课', 0.5);
INSERT INTO `lesson` VALUES ('大学英语(四)', '普通共同课', 3.0);
INSERT INTO `lesson` VALUES ('数字逻辑', '专业选修课', 2.0);
INSERT INTO `lesson` VALUES ('数字逻辑实验', '专业选修课', 0.5);
INSERT INTO `lesson` VALUES ('数学建模与MATLAB', '专业选修课', 2.0);
INSERT INTO `lesson` VALUES ('概率论与数理统计', '学科共同课', 3.0);
INSERT INTO `lesson` VALUES ('线性代数(理)', '学科共同课', 3.0);
INSERT INTO `lesson` VALUES ('计算机大类专业导论', '学科共同课', 2.0);
INSERT INTO `lesson` VALUES ('面向对象程序设计', '专业核心课', 3.0);
INSERT INTO `lesson` VALUES ('面向对象程序设计实验', '专业核心课', 1.0);
INSERT INTO `lesson` VALUES ('高等数学II(上)', '学科共同课', 6.0);
INSERT INTO `lesson` VALUES ('高级语言程序设计', '学科共同课', 3.0);
INSERT INTO `lesson` VALUES ('高级语言程序设计实验', '专业核心课', 1.0);

-- ----------------------------
-- Table structure for manager
-- ----------------------------
DROP TABLE IF EXISTS `manager`;
CREATE TABLE `manager`  (
  `SNo` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Monitor` varchar(4) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`SNo`, `Monitor`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of manager
-- ----------------------------
INSERT INTO `manager` VALUES ('1801110602', '体育委员');
INSERT INTO `manager` VALUES ('1806070417', '团支书');
INSERT INTO `manager` VALUES ('1812190208', '班长');
INSERT INTO `manager` VALUES ('1812190224', '心理委员');
INSERT INTO `manager` VALUES ('1812190226', '学习委员');
INSERT INTO `manager` VALUES ('1812190228', '组织委员');

-- ----------------------------
-- Table structure for personaladd
-- ----------------------------
DROP TABLE IF EXISTS `personaladd`;
CREATE TABLE `personaladd`  (
  `P_NUM` int NOT NULL,
  `P_Item` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `P_Score` float(3, 1) NULL DEFAULT NULL,
  PRIMARY KEY (`P_NUM`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of personaladd
-- ----------------------------
INSERT INTO `personaladd` VALUES (1, '积极参与班级建设，为班级学风建设做出贡献者', 2.0);
INSERT INTO `personaladd` VALUES (2, '积极参与班级建设，为班级学风建设做出突出贡献者', 4.0);
INSERT INTO `personaladd` VALUES (3, '参加学校、学院指定讲座', 1.0);
INSERT INTO `personaladd` VALUES (4, '参加学校、学院提倡的活动获学校通报表扬', 4.0);
INSERT INTO `personaladd` VALUES (5, '参加学校、学院提倡的活动获学院通报表扬', 2.0);
INSERT INTO `personaladd` VALUES (6, '一学期早自习出勤率达到100%', 2.0);
INSERT INTO `personaladd` VALUES (7, '有晚自习的年级寝室无熄灯违规的寝室长', 2.0);
INSERT INTO `personaladd` VALUES (8, '参加校级各类文体竞赛（活动，含运动会方阵等）未获奖者', 2.0);
INSERT INTO `personaladd` VALUES (9, '参加院级各类文体竞赛（活动，含运动会方阵等）未获奖者', 1.0);
INSERT INTO `personaladd` VALUES (10, '积极参加学校、学院组织的社会实践活动，以立项或提交的实践成果为准+1', 1.0);
INSERT INTO `personaladd` VALUES (11, '积极参加学校、学院组织的社会实践活动，以立项或提交的实践成果为准+2', 2.0);
INSERT INTO `personaladd` VALUES (12, '积极参加学校、学院组织的社会实践活动，以立项或提交的实践成果为准+3', 3.0);

-- ----------------------------
-- Table structure for personaladd1
-- ----------------------------
DROP TABLE IF EXISTS `personaladd1`;
CREATE TABLE `personaladd1`  (
  `SNo` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `P_Num` int NOT NULL,
  `P_Prove` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `P_isTrue` varchar(6) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `P_Score` float(3, 1) NULL DEFAULT NULL,
  PRIMARY KEY (`SNo`, `P_Num`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of personaladd1
-- ----------------------------

-- ----------------------------
-- Table structure for proskill
-- ----------------------------
DROP TABLE IF EXISTS `proskill`;
CREATE TABLE `proskill`  (
  `PS_NUM` int NOT NULL,
  `PS_Item` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `PS_Score` float(3, 1) NULL DEFAULT NULL,
  PRIMARY KEY (`PS_NUM`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of proskill
-- ----------------------------
INSERT INTO `proskill` VALUES (1, '获得英语六级考试资格即通过英语四级', 6.0);
INSERT INTO `proskill` VALUES (2, '英语四级考试中获得优秀', 10.0);
INSERT INTO `proskill` VALUES (3, '英语六级考试425分以上', 12.0);
INSERT INTO `proskill` VALUES (4, '英语六级考试中获得优秀', 15.0);
INSERT INTO `proskill` VALUES (5, '通过四级或六级口语考试', 2.0);
INSERT INTO `proskill` VALUES (6, '通过计算机等级考试二级', 6.0);
INSERT INTO `proskill` VALUES (7, '通过计算机等级考试三级', 10.0);
INSERT INTO `proskill` VALUES (8, '评比期间班级英语四级一次性通过率超过90%（含），且列年级第一名班级，班级中通过人员', 4.0);
INSERT INTO `proskill` VALUES (9, '评比期间班级英语四级一次性通过率超过90%（含），且列年级第二名班级，班级中通过人员', 2.0);
INSERT INTO `proskill` VALUES (10, '评比期间班级英语四级一次性通过率超过90%（含），且列年级第三名班级，班级中通过人员', 1.0);
INSERT INTO `proskill` VALUES (11, '计算机软件考试获得初级资格', 2.0);
INSERT INTO `proskill` VALUES (12, '计算机软件考试获得中级资格', 10.0);
INSERT INTO `proskill` VALUES (13, '计算机软件考试获得高级资格', 30.0);
INSERT INTO `proskill` VALUES (14, '通过上海市英语口译资格中级证书', 12.0);
INSERT INTO `proskill` VALUES (15, '通过上海是英语口译资格高级证书', 30.0);
INSERT INTO `proskill` VALUES (16, '取得剑桥商务英语证书BEC2', 4.0);
INSERT INTO `proskill` VALUES (17, '取得剑桥商务英语证书BEC3', 12.0);
INSERT INTO `proskill` VALUES (18, '托福考试成绩达80分及以上或雅思考试成绩达6.5分及以上', 12.0);
INSERT INTO `proskill` VALUES (19, '参加并完成硕士研究生考试', 12.0);
INSERT INTO `proskill` VALUES (20, '参加考研成绩良好者（文科280分，理科250分以上）', 20.0);

-- ----------------------------
-- Table structure for proskill1
-- ----------------------------
DROP TABLE IF EXISTS `proskill1`;
CREATE TABLE `proskill1`  (
  `SNo` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `PS_Num` int NOT NULL,
  `PS_Prove` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `PS_isTrue` varchar(6) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `PS_Score` float(3, 1) NULL DEFAULT NULL,
  PRIMARY KEY (`SNo`, `PS_Num`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of proskill1
-- ----------------------------

-- ----------------------------
-- Table structure for qscore
-- ----------------------------
DROP TABLE IF EXISTS `qscore`;
CREATE TABLE `qscore`  (
  `SNo` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `QScore` float(3, 1) NULL DEFAULT NULL,
  PRIMARY KEY (`SNo`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of qscore
-- ----------------------------
INSERT INTO `qscore` VALUES ('1402080224', NULL);
INSERT INTO `qscore` VALUES ('1710080232', NULL);
INSERT INTO `qscore` VALUES ('1801110602', NULL);
INSERT INTO `qscore` VALUES ('1805090112', NULL);
INSERT INTO `qscore` VALUES ('1805090221', NULL);
INSERT INTO `qscore` VALUES ('1805100214', NULL);
INSERT INTO `qscore` VALUES ('1805100341', NULL);
INSERT INTO `qscore` VALUES ('1806070417', NULL);
INSERT INTO `qscore` VALUES ('1807090414', NULL);
INSERT INTO `qscore` VALUES ('1810080435', NULL);
INSERT INTO `qscore` VALUES ('1811060137', NULL);
INSERT INTO `qscore` VALUES ('1812190202', NULL);
INSERT INTO `qscore` VALUES ('1812190208', NULL);
INSERT INTO `qscore` VALUES ('1812190210', NULL);
INSERT INTO `qscore` VALUES ('1812190218', NULL);
INSERT INTO `qscore` VALUES ('1812190219', NULL);
INSERT INTO `qscore` VALUES ('1812190220', NULL);
INSERT INTO `qscore` VALUES ('1812190224', NULL);
INSERT INTO `qscore` VALUES ('1812190226', NULL);
INSERT INTO `qscore` VALUES ('1812190227', NULL);
INSERT INTO `qscore` VALUES ('1812190228', NULL);
INSERT INTO `qscore` VALUES ('1812190229', NULL);
INSERT INTO `qscore` VALUES ('1812190230', NULL);
INSERT INTO `qscore` VALUES ('1812190231', NULL);
INSERT INTO `qscore` VALUES ('1812190232', NULL);
INSERT INTO `qscore` VALUES ('1812190503', NULL);
INSERT INTO `qscore` VALUES ('1812190505', NULL);
INSERT INTO `qscore` VALUES ('1812190509', NULL);
INSERT INTO `qscore` VALUES ('1812190521', NULL);
INSERT INTO `qscore` VALUES ('1812190522', NULL);
INSERT INTO `qscore` VALUES ('1812190532', NULL);
INSERT INTO `qscore` VALUES ('1819130205', NULL);
INSERT INTO `qscore` VALUES ('1820100608', NULL);
INSERT INTO `qscore` VALUES ('1820100703', NULL);
INSERT INTO `qscore` VALUES ('1822010211', NULL);
INSERT INTO `qscore` VALUES ('1823040320', NULL);
INSERT INTO `qscore` VALUES ('1835010206', NULL);
INSERT INTO `qscore` VALUES ('1835020601', NULL);

-- ----------------------------
-- Table structure for research
-- ----------------------------
DROP TABLE IF EXISTS `research`;
CREATE TABLE `research`  (
  `R_NUM` int NOT NULL,
  `R_Item` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `R_Score` float(3, 1) NULL DEFAULT NULL,
  PRIMARY KEY (`R_NUM`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of research
-- ----------------------------
INSERT INTO `research` VALUES (1, '参加国家及竞赛获得一等奖', 50.0);
INSERT INTO `research` VALUES (2, '参加国家级竞赛获得二等奖', 35.0);
INSERT INTO `research` VALUES (3, '参加国家级竞赛获得三等奖', 30.0);
INSERT INTO `research` VALUES (4, '参加国家级竞赛参与奖', 10.0);
INSERT INTO `research` VALUES (5, '参加省部级竞赛获得一等奖', 30.0);
INSERT INTO `research` VALUES (6, '参加省部级竞赛获得二等奖', 20.0);
INSERT INTO `research` VALUES (7, '参加省部级竞赛获得三等奖', 15.0);
INSERT INTO `research` VALUES (8, '参加省部级竞赛参与奖', 5.0);
INSERT INTO `research` VALUES (9, '参加校级竞赛获得一等奖', 12.0);
INSERT INTO `research` VALUES (10, '参加校级竞赛获得二等奖', 8.0);
INSERT INTO `research` VALUES (11, '参加校级竞赛获得三等奖', 5.0);
INSERT INTO `research` VALUES (12, '参加校级竞赛参与奖', 3.0);
INSERT INTO `research` VALUES (13, '参加院级竞赛获得一等奖', 5.0);
INSERT INTO `research` VALUES (14, '参加院级竞赛获得二等奖', 3.0);
INSERT INTO `research` VALUES (15, '参加院级竞赛获得三等奖', 2.0);
INSERT INTO `research` VALUES (16, '参加院级竞赛参与奖', 1.0);
INSERT INTO `research` VALUES (17, '发表一级刊物', 50.0);
INSERT INTO `research` VALUES (18, '发表二级刊物', 25.0);
INSERT INTO `research` VALUES (19, '发表三级刊物', 15.0);
INSERT INTO `research` VALUES (20, '在全国性报纸上发表文章', 10.0);
INSERT INTO `research` VALUES (21, '在地方性报纸上发表文章', 5.0);
INSERT INTO `research` VALUES (22, '被邀参加国际学术会议或国家级学术研讨会', 12.0);
INSERT INTO `research` VALUES (23, '在国际学术会议或国家级学术研讨会上作主题发言宣读论文', 20.0);

-- ----------------------------
-- Table structure for research1
-- ----------------------------
DROP TABLE IF EXISTS `research1`;
CREATE TABLE `research1`  (
  `SNo` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `R_Num` int NOT NULL,
  `R_Prove` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `R_isTrue` varchar(6) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `R_Score` float(3, 1) NULL DEFAULT NULL,
  PRIMARY KEY (`SNo`, `R_Num`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of research1
-- ----------------------------

-- ----------------------------
-- Table structure for signin
-- ----------------------------
DROP TABLE IF EXISTS `signin`;
CREATE TABLE `signin`  (
  `SNo` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `PassWord` varchar(18) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  PRIMARY KEY (`SNo`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of signin
-- ----------------------------
INSERT INTO `signin` VALUES ('123', '123123');
INSERT INTO `signin` VALUES ('123123', '2354234');
INSERT INTO `signin` VALUES ('1812190207', '123321');
INSERT INTO `signin` VALUES ('1812190208', 'chenh');
INSERT INTO `signin` VALUES ('1812190219', 'gyqgyq');

-- ----------------------------
-- Table structure for sinfo
-- ----------------------------
DROP TABLE IF EXISTS `sinfo`;
CREATE TABLE `sinfo`  (
  `SNo` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `SNation` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `SName` varchar(8) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `SSex` char(2) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `Sdata` date NULL DEFAULT NULL,
  `SID` varchar(18) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `SHigh` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `SNP` varchar(12) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `SHP` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `SPhone` varchar(12) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `SFP` varchar(12) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `SMP` varchar(12) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `SQQ` varchar(12) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `SPO` varchar(4) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `SRB` varchar(4) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `SDN` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `SICBC` varchar(19) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `note` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  PRIMARY KEY (`SNo`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sinfo
-- ----------------------------
INSERT INTO `sinfo` VALUES ('1402080224', '汉族', '黄振鹏', '男', '1995-11-04', '330227199511046472', '浙江省鄞州高级中学', '浙江宁波', '浙江省宁波市海曙区高桥镇高桥村陈家66号', '15868406074', '13906613178', '17671330405', '522092212', '共青团员', '无', '29#317', '6212261202018935453', NULL);
INSERT INTO `sinfo` VALUES ('1710080232', '汉族', '陈佳威', '男', '1998-10-19', '330483199810190000', '桐乡市高级中学', '浙江嘉兴', '浙江省桐乡市崇福镇锦绣家园12幢三单元102室', '18758079643', '13511385846', '13666747511', '619009031', '共青团员', '无', '44#116', '6212261202041216350', NULL);
INSERT INTO `sinfo` VALUES ('1801110602', '汉族', '池子涵', '男', '2000-10-28', '341122200010282216', '安徽省来安中学', '安徽滁州', '安徽省滁州市来安县雷官镇', '19858192759', '18355020232', '15249980885', '2697872262', '共青团员', '无', '30#424', '6212261202046762937', NULL);
INSERT INTO `sinfo` VALUES ('1805090112', '汉族', '孙婧沂', '女', '2000-03-03', '370687200003030045', '烟台市中英文学校', '山东省烟台市', '山东省烟台市海阳市西哲阳小区14号楼2单元', '17367108447', '13953558570', '15154530577', '627941189', '共青团员', '无', '34#205', '', NULL);
INSERT INTO `sinfo` VALUES ('1805090221', '汉族', '周欣怡', '女', '1999-11-15', '330421199911150044', '嘉善中学', '浙江省嘉兴市', '浙江省嘉兴市嘉善县魏塘街道智果新区33号', '19857113080', '无', '13456368366', '1623641298', '共青团员', '无', '34#208', '6212261202046770000', NULL);
INSERT INTO `sinfo` VALUES ('1805100214', '汉族', '周知乐', '女', '2000-11-24', '362531200011240045', '东乡区第一中学', '江西东乡', '江西省抚州市东乡区毛莲山南区28号', '17707016659', '13879439722', '13970400582', '1638124979', '共青团员', '无', '34#315', '6212261202046773033', NULL);
INSERT INTO `sinfo` VALUES ('1805100341', '汉族', '李思思', '女', '2000-06-08', '330324200006080022', '浙江省永嘉中学', '浙江', '浙江省温州市永嘉县电业大楼2-D21', '18758098405', '13868631528', '13588931903', '3369489202', '共青团员', '佛教', '34#326', '6212261202046773728', NULL);
INSERT INTO `sinfo` VALUES ('1806070417', '汉族', '林俊辉', '男', '2001-01-08', '362324200101084512', '浙江省乐清中学', '浙江温州', '浙江温州市乐清市柳市镇前窑村', '19857113231', '18858798131', '1625871756', '1073930065', '共青团员', '无', '29#409', '6212261202046775608', NULL);
INSERT INTO `sinfo` VALUES ('1807090414', '汉族', '陈达圣', '男', '2000-10-27', '330382200010274712', '浙江省乐清中学', '浙江乐清', '浙江省乐清市蒲岐镇香格里拉B幢601室', '15868414147', '13521181821', '13683294573', '1532988164', '共青团员', '无', '29#619', '6212261202046777604', NULL);
INSERT INTO `sinfo` VALUES ('1810080435', '汉族', '陈玮莹', '女', '2000-03-29', '511011200003295083', '楚门中学', '四川', '浙江省台州市玉环坎门', '19857113196', '15967056444', '13566832457', '1535967840', '共青团员', '无', '35#102', '6212261202046784154', NULL);
INSERT INTO `sinfo` VALUES ('1811060137', '汉族', '冯佳琪', '女', '1999-08-23', '330621199908235945', '绍兴市第一中学', '浙江省绍兴市', '浙江省绍兴市越城区鉴湖街道彩虹名家10幢1302室', '17367107697', '13819582583', '13735296158', '1736818659', '共青团员', '无', '33#526', '6212261202046785227', NULL);
INSERT INTO `sinfo` VALUES ('1812120208', '土家', '陈浩然1', '男', '2000-03-21', '42280120000321161X', '恩施高中', '湖北恩施', '湖北恩施', '13329825566', '13197200165', '15307262009', '1553442305', '共青团员', '无', '29#321', '123', '无');
INSERT INTO `sinfo` VALUES ('1812190202', '汉族', '管楠楠', '女', '2000-06-11', '340223200006110527', '安徽省南陵中学', '安徽芜湖', '浙江省芜湖市南陵县印象剑桥', '17367103028', '13855328153', '13955394980', '2287260726', '共青团员', '无', '46#816', '6212261202046787967', NULL);
INSERT INTO `sinfo` VALUES ('1812190210', '汉族', '刘双', '女', '2000-01-25', '370781200001253269', '山东省现代中学', '山东潍坊', '山东省潍坊市青州市东夏镇张晁村', '17367103889', '15964325131', '15854485050', '1243516272', '共青团员', '无', '46#817', '6212261202046788049', NULL);
INSERT INTO `sinfo` VALUES ('1812190218', '汉族', '孙倩', '女', '2000-01-17', '330724200001176924', '浙江省东阳第二高级中学', '浙江东阳', '浙江省东阳市千祥镇三联大路孔宅村', '17395712468', '15067588284', '18907572803', '1425869570', '共青团员', '无', '46#818', '6212261202046788122', NULL);
INSERT INTO `sinfo` VALUES ('1812190220', '汉族', '骆添', '男', '2000-01-14', '330421200001143211', '浙江省嘉善高级中学', '浙江嘉兴', '浙江嘉兴市嘉善县姚庄镇洪福路329号', '15067365425', '13857378351', '15988362576', '282725559', '共青团员', '无', '29#324', '6212261202046788148', NULL);
INSERT INTO `sinfo` VALUES ('1812190224', '汉族', '应岳良', '男', '1999-07-17', '330226199907172399', '宁海中学', '浙江宁海', '浙江省宁海县兴宁中路1号丰和苑1幢402', '15757455799', '13906606355', '13968344396', '942215134', '共青团员', '无', '29#326', '6212261202046788189', NULL);
INSERT INTO `sinfo` VALUES ('1812190226', '汉族', '林俊彦', '男', '2000-08-01', '330381200008011618', '上外附属海宁宏达高中', '浙江温州', '浙江省瑞安市塘下镇场桥镇东街26号', '17367107694', '13857367586', '13157310222', '1528219849', '群众', '无', '29#326', '6212261202046788205', NULL);
INSERT INTO `sinfo` VALUES ('1812190227', '汉族', '郑营锋', '男', '2000-05-03', '331022200005030973', '浙江省三门中学', '浙江台州', '浙江省台州市三门县高枧村枧水路98号', '17395711165', '18705869980', '13968508566', '1264219673', '共青团员', '无', '29#325', '6212261202046788213', NULL);
INSERT INTO `sinfo` VALUES ('1812190228', '汉族', '孔启超', '男', '1999-11-29', '330102199911290017', '浙江省夏衍中学', '浙江杭州', '浙江省杭州市江干区美都雅苑1-3-1202', '13606636413', '137035873022', '13857120931', '631410882', '共青团员', '无', '29#325', '6212261202046788221', NULL);
INSERT INTO `sinfo` VALUES ('1812190229', '汉族', '方正', '男', '1999-09-21', '330106199909214010', '上海外国语大学附属海宁宏达高级中学', '浙江杭州', '浙江杭州市江干区彭埠街道世茂茂悦府3幢1004', '13958054439', '13605819011', '13735473969', '1256226752', '共青团员', '无', '29#325', '6212261202046788239', NULL);
INSERT INTO `sinfo` VALUES ('1812190230', '汉族', '姚紫城', '男', '1999-12-14', '330682199912145910', '浙江省春晖中学', '浙江绍兴', '浙江省绍兴市上虞区丰惠镇东门村（北村）158号', '19858192682', '13967523226', '15215979282', '1531837464', '共青团员', '无', '29#325', '6212261202046788247', NULL);
INSERT INTO `sinfo` VALUES ('1812190231', '汉族', '陈国栋', '男', '1998-11-14', '330682199811141419', '浙江省崧厦中学', '浙江绍兴', '浙江省绍兴市上虞区谢塘镇晋盛家园10栋', '17395711129', '13967521012', '13858455330', '549208414', '共青团员', '无', '29#328', '6212261202046788254', NULL);
INSERT INTO `sinfo` VALUES ('1812190232', '汉族', '徐家云', '男', '1999-09-02', '339005199909020319', '萧山第三高级中学', '浙江杭州', '杭州市萧山区蜀山街道鲁公桥社区', '18657167547', '13606636346', '18958111693', '1310246894', '共青团员', '无', '29#328', '6212261202046788262', NULL);
INSERT INTO `sinfo` VALUES ('1812190503', '汉族', '王龙', '男', '1992-06-06', '342221199206069235', '安徽省六安中学', '安徽砀山', '安徽省砀山县唐寨镇汪庄村', '17367107842', '13866495083', '15856278395', '571924673', '群众', '无', '29#413', '6212261202046789013', NULL);
INSERT INTO `sinfo` VALUES ('1812190505', '汉族', '黄茂祥', '男', '1999-09-20', '350601199909200013', '福建省厦门大学附属实验中学', '福建漳州', '福建省漳州市漳州开发区店地社区余厝5号', '17367107943', '13559665428', '无', '1572717834', '共青团员', '无', '29#413', '6212261202046789039', NULL);
INSERT INTO `sinfo` VALUES ('1812190509', '汉族', '米义嘉', '男', '1999-11-27', '510183199911270018', '四川省绵阳南山中学', '四川邛崃', '四川省成都市邛崃市惠民小区17栋3单元10号', '17367107843', '13550187567', '无', '1075581168', '共青团员', '无', '29#413', '6212261202046789070', NULL);
INSERT INTO `sinfo` VALUES ('1812190521', '汉族', '单好佳', '女', '1999-10-28', '331121199910280327', '浙江省缙云中学', '浙江丽水', '浙江丽水遂昌妙高镇北街27弄12号2幢301', '15988087251', '18058162302', '18058778565', '646767656', '共青团员', '无', '46#824', '6212261202046789795', NULL);
INSERT INTO `sinfo` VALUES ('1812190522', '汉族', '陈娇妮', '女', '2000-02-14', '330381200002144022', '浙江省瑞安中学', '浙江温州', '浙江省温州市瑞安市仙降街道塘头村联盛楼苑B单元701室', '19858192906', '15377666788', '13967728515', '1161344829', '共青团员', '无', '46#824', '6212261202046789203', NULL);
INSERT INTO `sinfo` VALUES ('1812190532', '汉族', '褚俊杰', '男', '2000-07-22', '332523200007220011', '浙江省云和中学', '浙江丽水', '浙江市丽水市云和县水镜佳苑', '13073699702', '649373', '653423', '837929505', '共青团员', '无', '29#420', '6212261202046789302', NULL);
INSERT INTO `sinfo` VALUES ('1819130205', '汉族', '陆小文', '女', '2000-03-01', '340502200003010226', '安徽省马鞍山市第二中学', '安徽马鞍山', '安徽省马鞍山市花山区秀山郡41-1207', '13173693208', '13865553792', '13865556294', '516008756', '共青团员', '无', '33#513', '6212261306002699338', NULL);
INSERT INTO `sinfo` VALUES ('1820100608', '苗族', '陈泫冰', '女', '2000-09-03', '520114200009030428', '观山湖区第一高级中学', '贵州贵阳', '贵州省贵阳市花溪区兴隆城市花园桃源居10-1-2-4', '17367107931', '13985040998', '15985019611', '670367026', '共青团员', '无', '42#118', '6212261202046793601', NULL);
INSERT INTO `sinfo` VALUES ('1820100703', '汉族', '江晓燕', '女', '2000-07-26', '342501200007260287', '安徽省宣城市宣城中学', '安徽', '安徽省宣城市宣州区澄江街道宣城昭亭北路盛宇湖畔17栋504', '13758226754', '13013133133', '13205631425', '1369964362', '共青团员', '无', '42#323', '6212261202046793916', NULL);
INSERT INTO `sinfo` VALUES ('1822010211', '汉族', '王泽龙', '男', '2000-09-01', '370281200009017000', '山东省青岛市胶州市实验中学', '山东省青岛市胶州市', '山东省青岛市胶州市营海镇马家辛庄村307号', '18758170823', '15253215673', '13455258938', '2867706330', '共青团员', '无', '43#623', '6212261202046794690', NULL);
INSERT INTO `sinfo` VALUES ('1823040320', '汉族', '王相林', '男', '2000-11-09', '331002200011092534', '台州市第一中学', '浙江省台州市 ', '浙江省台州市椒江区章安街道蔡桥村后洋陈16号', '15868412148', '13116917976', '15257610359', '1830638446', '共青团员', '无', '43#211', '6212261202046796240', NULL);
INSERT INTO `sinfo` VALUES ('1835010206', '汉族', '马媛媛  ', '女', '1999-08-18', '622627199908180023', '甘肃省西和县第一中学', '甘肃省西和县', '甘肃省西和县汉源镇北关四组朝阳路居民区65号', '19857112667', '15293398485', '18309394801', '550402122', '共青团员', '无', '46#308', '6212261202046797891', NULL);

-- ----------------------------
-- Table structure for social
-- ----------------------------
DROP TABLE IF EXISTS `social`;
CREATE TABLE `social`  (
  `So_NUM` int NOT NULL,
  `So_Item` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `So_Score` float(3, 1) NULL DEFAULT NULL,
  PRIMARY KEY (`So_NUM`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of social
-- ----------------------------
INSERT INTO `social` VALUES (1, '国家级媒体录用1篇', 20.0);
INSERT INTO `social` VALUES (2, '省级媒体录用1篇', 15.0);
INSERT INTO `social` VALUES (3, '地市级和县级媒体录用1篇', 10.0);
INSERT INTO `social` VALUES (4, '校报、校园内部网录用1篇', 5.0);
INSERT INTO `social` VALUES (5, '商大青年网和学院网站发表文章录用1篇', 2.0);
INSERT INTO `social` VALUES (6, '获得校级社会实践先进个人、优秀论文荣誉', 10.0);
INSERT INTO `social` VALUES (7, '社会实践受省级表彰的团队，组长及宣传员等主要负责人', 20.0);
INSERT INTO `social` VALUES (8, '社会实践受省级表彰的团队，其他成员', 10.0);
INSERT INTO `social` VALUES (9, '获校级表彰的实践团队，组长及宣传员等主要负责人', 10.0);
INSERT INTO `social` VALUES (10, '获校级表彰的实践团队，其他成员', 5.0);

-- ----------------------------
-- Table structure for social1
-- ----------------------------
DROP TABLE IF EXISTS `social1`;
CREATE TABLE `social1`  (
  `SNo` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `So_Num` int NOT NULL,
  `So_Prove` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `So_isTrue` varchar(6) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `So_Score` float(3, 1) NULL DEFAULT NULL,
  PRIMARY KEY (`SNo`, `So_Num`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of social1
-- ----------------------------

-- ----------------------------
-- Table structure for sports
-- ----------------------------
DROP TABLE IF EXISTS `sports`;
CREATE TABLE `sports`  (
  `Sp_NUM` int NOT NULL,
  `Sp_Item` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `Sp_Score` float(3, 1) NULL DEFAULT NULL,
  PRIMARY KEY (`Sp_NUM`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sports
-- ----------------------------
INSERT INTO `sports` VALUES (1, '参加国家级比赛获得一等奖', 50.0);
INSERT INTO `sports` VALUES (2, '参加国家级比赛获得二等奖', 35.0);
INSERT INTO `sports` VALUES (3, '参加国家级比赛获得三等奖', 25.0);
INSERT INTO `sports` VALUES (4, '参加国家级比赛获得参与奖', 15.0);
INSERT INTO `sports` VALUES (5, '参加省部级比赛获得一等奖', 30.0);
INSERT INTO `sports` VALUES (6, '参加省部级比赛获得二等奖', 20.0);
INSERT INTO `sports` VALUES (7, '参加省部级比赛获得三等奖', 10.0);
INSERT INTO `sports` VALUES (8, '参加省部级比赛获得参与奖', 8.0);
INSERT INTO `sports` VALUES (9, '参加市级比赛获得一等奖', 18.0);
INSERT INTO `sports` VALUES (10, '参加市级比赛获得二等奖', 12.0);
INSERT INTO `sports` VALUES (11, '参加市级比赛获得三等奖', 8.0);
INSERT INTO `sports` VALUES (12, '参加校级比赛获得一等奖', 12.0);
INSERT INTO `sports` VALUES (13, '参加校级比赛获得二等奖', 8.0);
INSERT INTO `sports` VALUES (14, '参加校级比赛获得三等奖', 5.0);
INSERT INTO `sports` VALUES (15, '参加院级比赛获得一等奖', 5.0);
INSERT INTO `sports` VALUES (16, '参加院级比赛获得二等奖', 3.0);
INSERT INTO `sports` VALUES (17, '参加院级比赛获得三等奖', 2.0);
INSERT INTO `sports` VALUES (18, '校运会破纪录', 20.0);
INSERT INTO `sports` VALUES (19, '校级以上体育赛事破纪录', 30.0);
INSERT INTO `sports` VALUES (20, '称为年度国家二级运动员', 10.0);

-- ----------------------------
-- Table structure for sports1
-- ----------------------------
DROP TABLE IF EXISTS `sports1`;
CREATE TABLE `sports1`  (
  `SNo` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Sp_Num` int NOT NULL,
  `Sp_Prove` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `Sp_isTrue` varchar(6) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `Sp_Score` float(3, 1) NULL DEFAULT NULL,
  PRIMARY KEY (`SNo`, `Sp_Num`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sports1
-- ----------------------------

SET FOREIGN_KEY_CHECKS = 1;
