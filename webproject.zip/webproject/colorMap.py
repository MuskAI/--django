import cv2

im_gray = cv2.imread("C:\\Users\\musk\\Desktop\\28.png", cv2.IMREAD_GRAYSCALE)

im_color = cv2.applyColorMap(im_gray, cv2.COLORMAP_JET)
cv2.namedWindow('1')
cv2.imshow("1",im_color)
cv2.waitKey(0)